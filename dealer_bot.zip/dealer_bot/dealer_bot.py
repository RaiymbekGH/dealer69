import os

import disnake
from disnake.ext import commands
import asyncio
"""
try:
    from dotenv import load_dotenv
    load_dotenv()  # подхватывает .env рядом с этим файлом, если он есть (pip install python-dotenv)
except ImportError:
    pass  # необязательная зависимость — на хостинге переменные обычно задаются в панели проекта
"""
# ========== ТОКЕН ==========
# Токен НЕ хранится в коде — берётся из переменной окружения DISCORD_TOKEN.
# Локально (Pydroid3): в Termux/окружении пропишите перед запуском
#   export DISCORD_TOKEN="ваш_токен"
# либо создайте файл .env рядом с этим файлом (см. README про python-dotenv).
# На хостинге (Railway/Render/etc.) — впишите DISCORD_TOKEN в их разделе
# "Environment Variables" в панели проекта, в код его вписывать не нужно.
TOKEN = "MTUyMTMyNTY2OTk5NTUxNjAwNQ.GAnx0o.d1BWZKMwZaS7LPS1XAC_YNCX33VIe2F7zY0wmQ"
#TOKEN = os.environ.get("DISCORD_TOKEN")
if not TOKEN:
    raise RuntimeError(
        "Не найден токен бота. Установите переменную окружения DISCORD_TOKEN "
        "(значение — ваш токен из Discord Developer Portal)."
    )

# ========== ИНТЕНТЫ ==========
intents = disnake.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix="!", intents=intents)

#
DEFAULT_ANKETA_CONFIG = {
    "color": 0xED4245,
    "post_content": "{mention}, ищет людей!",
    "mention_roles": [],
    "fields": [
        {"label": "О себе", "placeholder": "Напишите о себе...", "min_length": 1, "max_length": 1000, "style": "paragraph", "custom_id": "about", "required": True},
        {"label": "Кого ищу", "placeholder": "Кого вы ищете?", "min_length": 1, "max_length": 1000, "style": "paragraph", "custom_id": "looking", "required": True},
        {"label": "Для каких целей", "placeholder": "Цель анкеты?", "min_length": 1, "max_length": 1000, "style": "short", "custom_id": "purpose", "required": True}
    ],
    "button_label": "Оставить заявку",
    "button_style": "primary",
    "invite_text": "Оставьте заявку, заполнив форму кнопкой ниже.",
    "cooldown_seconds": 900,
# Например: 86400 = раз в сутки, 3600 = раз в час.
#=========================
}
ANKETA_CONFIGS = {
    1518993953163055236: {
        "title": "🔍 Найти людей для различных целей",
        "invite_text": "Если вы ищете кого либо для различных целей то оставьте заявку, заполнив короткую форму. Для начала нажмите на кнопку."
    },
    1522468136002261145: {
        "title": "Трейды и продолжения по обмену",
        "mention_roles": [1522614447397671035],   
        "fields": [
            {"label": "Игры/игра/режим", "placeholder": "В какой игре вы хотите обменяться...", "min_length": 1, "max_length": 1000, "style": "short", "custom_id": "about", "required": True},
            {"label": "🔺Что предлагаю/даю", "placeholder": "что вы хотите предложить...", "min_length": 1, "max_length": 1000, "style": "paragraph", "custom_id": "looking", "required": True},
            {"label": "🔻Что получаю/беру", "placeholder": "что вы хотите получить...", "min_length": 1, "max_length": 1000, "style": "paragraph", "custom_id": "purpose", "required": True},
        ],
        "invite_text": "Хочешь обменяться вещами или предложить услуги? Оставить заявку  кнопкой ниже и заполни короткую форму.",
        "post_content": "{mention}, предлагает",
        "button_label": "Предложить обмен",
        "button_style": "success"
    },
    1519014376139395102: {
        "title": "Найти людей в **Steam**",
        "post_content": "{mention} ищет людей в **Steam**!",
        "fields": [
            {"label": "Кого ищу", "placeholder": "кого вы ищете?", "min_length": 1, "max_length": 500, "style": "paragraph", "custom_id": "looking", "required": True},
            {"label": "Игры/игра", "placeholder": "игры/игра?", "min_length": 1, "max_length": 500, "style": "short", "custom_id": "purpose", "required": True}
        ],
        "invite_text": "Хочешь найти компанию или друга для игр **Steam**? Оставить заявку кнопкой ниже и заполни короткую форму."
    },
    1519014405470421132: {
        "title": "Найти людей в **Roblox**",
        "post_content": "{mention} ищет людей в **Roblox**!",
        "fields": [
            {"label": "Кого ищу", "placeholder": "кого вы ищете?", "min_length": 1, "max_length": 500, "style": "paragraph", "custom_id": "looking", "required": True},
            {"label": "Режим/игра", "placeholder": "режим/игра?", "min_length": 1, "max_length": 500, "style": "short", "custom_id": "purpose", "required": True}
        ],
        "invite_text": "Хочешь найти компанию или друга для игр в **Roblox**? Оставить заявку кнопкой ниже и заполни короткую форму."
    }
}
#=========================
DEFAULT_TICKET_CONFIG = {
    "mode": "menu",
    "support_roles": [],
    "topics": [
        {"label": "Общий вопрос", "value": "general", "description": "Любые вопросы по серверу"},
        {"label": "Другое", "value": "other", "description": "Прочие обращения"}
    ],
    "default_topic_label": "Обращение",
    "default_topic_value": "default",
    "button_label": "🎫 Создать тикет",
    "button_style": "green",
    "embed_title": "🎫 Система поддержки",
    "embed_description": "Нажмите на кнопку ниже, чтобы создать тикет.",
    "embed_color": 0xED4245,
    "embed_footer": None,
    "ticket_embed_title": "🎫 Ваш тикет создан!",
    "ticket_embed_color": 0xED4245,
    "ticket_embed_footer": "Создатель: {author}",
    "close_button_label": "Закрыть тикет",
    "close_button_style": "danger",
    "close_button_emoji": "🔒",
    "modal_title": "Создание тикета",
    "modal_fields": [
        {
            "custom_id": "description",
            "label": "Краткое описание проблемы",
            "placeholder": "Опишите суть обращения...",
            "style": "paragraph",   # "short" | "paragraph"
            "min_length": 5,
            "max_length": 1000,
            "required": True,
        },
    ]
}
TICKET_CONFIGS = {
    1518992177647063130: {
        "category_id": 1518979351855501423,
        "support_roles": [1519951628562727085, 1519951870884577410],
        "mode": "menu",
        "topics": [
            {"label": "Вопрос по серверу", "value": "anketa", "description": "Помощь с вопросами по серверу", "emoji": "<:Questions_problems:1528536799373430925>"},
            {"label": "Техническая проблема", "value": "tech", "description": "Ошибк, баг, неработающие функции", "emoji": "<:Bug:1528536801080246282>"},
            {"label": "Жалобы", "value": "moderation", "description": "Жалоба на пользователя или модератора", "emoji": "<:Complaints:1528536804138160218>"},
            {"label": "Другое", "value": "other", "description": "Любые другие вопросы и проблемы", "emoji": "<:Other_problem:1528536802720350370>"}
        ],
        "embed_title": "🎫 Обратится к поддержке",
        "embed_description": "Нажмите на кнопку ниже, чтобы открыть тикет.",
        "embed_footer": "Поддержка ответит в ближайшее время",
        "ticket_embed_title": "Ваше обращение принято!",
        "button_label": "Открыть тикет",
        "button_emoji": "<:Ticket:1528999378159931484>",
        "button_style": "primary",
        "close_button_label": "Закрыть обращение",
        "close_button_style": "danger",
        "close_button_emoji": "<:Close:1528537960994050148>"
    },
    1518993494541205534: {
        "category_id": 1518979351855501423,
        "support_roles": [1519951628562727085, 1519951870884577410],
        "mode": "modal",
        "embed_title": "🎫 Стать частью поддержки сервера",
        "embed_description": "Хочешь стать частью поддержки сервера? \nЗаполните форму ниже, чтобы подать заявку.",
        "button_label": "Подать заявку",
        "button_style": "primary",
        "button_emoji": "<:Ticket:1528999378159931484>",
        "modal_title": "modular window for support",
        "modal_fields": [
            {"custom_id": "age", "label": "Возраст", "placeholder": "Сколько вам лет?",
             "style": "short", "min_length": 1, "max_length": 2, "required": True},
            {"custom_id": "time", "label": "Сколько часов в день готовы уделять?", "placeholder": "Ежедневно в день",
             "style": "short", "min_length": 1, "max_length": 2, "required": True},
            {"custom_id": "about", "label": "Кратко о себе", "placeholder": "Напишите почему хотите стать частью поддержки",
             "style": "short", "min_length": 20, "max_length": 1000, "required": True},
        ],
       "embed_footer": "Заявки рассматриваются до 48 часов"
    }
}
#=========================
DEFAULT_SUGGESTION_CONFIG = {
    "embed_color": None,
    "panel_title": "Педложения по серверу",
    "panel_description": "Есть идея, как сделать сервер лучше? Поделитесь!",
    "button_label": "Педложить идею",
    "button_style": "primary",
    "modal_title": "Новое предложение",
    "field_label": "Ваше предложение",
    "field_placeholder": "Опишите идею подробно...",
    "min_length": 10,
    "max_length": 1000,
    "anonymous": False, # скрывать автора в опубликованном предложении
    # ---------- ГОЛОСОВАНИЕ ----------
    "voting_enabled": True, # False — кнопок голоса не будет вообще, останется только модерация
    "upvote_emoji": "<:Votefor:1527246152356069416>",
    "downvote_emoji": "<:Voteagainst:1527246150531547226>",

    "review_roles": [], # роли, которые могут одобрять/отклонять (+ администраторы всегда могут)
    "blocked_create_roles": [], # роли, которые не могут создавать пред.
    "blocked_vote_roles": [], # роли, которые не могу голосовать
    "vote_roles": [], # роли, кому можно голосовать
    "require_reason_on_reject": True, # при отклонении модератор указывает причину
    "cooldown_seconds": 0,
    # "feed_channel_id": None, # опубликовать в ДРУГОЙ канал, а не там, где панель
}
SUGGESTION_CONFIGS = {
     1518993073411985498: {
          "review_roles": [1519951628562727085],
          "blocked_create_roles": [], # не могут создавать пред.
          "blocked_vote_roles": [], # не могу голосовать
          "vote_roles": [], # можно голосовать
          "embed_color": 0xD82318,
          "cooldown_seconds": 86400,
     },
}
# ========== КОНФИГ МОДЕРАЦИИ ==========
# ПРАВА ПО РОЛЯМ (role_permissions):
# Гибкая система — каждая роль получает свой набор команд, и по каждой
# команде можно задать кулдаун (в секундах) на одного модератора.
# Если у участника несколько подходящих ролей — берётся САМЫЙ ШИРОКИЙ
# доступ и МИНИМАЛЬНЫЙ кулдаун среди них (роли складываются, а не спорят).
# Для warn можно ограничить, какие именно уровни доступны роли (levels).
#
# Пример — младшая модерация может только warn 1 уровня, раз в 2 часа:
#     {
#         "role_id": 111111111111111111,
#         "commands": {
#             "warn": {"levels": [1], "cooldown_seconds": 7200},
#         },
#     }
# Пример — обычная модерация: все уровни warn без ограничений + другие команды:
#     {
#         "role_id": 222222222222222222,
#         "commands": {
#             "warn": {"levels": [1, 2, 3], "cooldown_seconds": 0},
#             "mute": {"cooldown_seconds": 0},
#             "kick": {"cooldown_seconds": 0},
#             "ban": {"cooldown_seconds": 0},
#             "clear": {"cooldown_seconds": 0},
#             "re": {"cooldown_seconds": 0},
#             "warnings": {"cooldown_seconds": 0},
#             "unwarn": {"cooldown_seconds": 0},
#         },
#     }
DEFAULT_MODERATION_CONFIG = {
    "mod_roles": [], # роли с ПОЛНЫМ доступом ко всем командам без кулдаунов (+ администраторы)
    "role_permissions": [], # тонко настроенные роли
    "log_channel_id": None, # канал для лога действий модерации (None — не логировать)
    "level_points": {1: 1, 2: 2, 3: 3}, # сколько очков даёт предупреждение каждого уровня
    # Если для уровня 2 не указали срок — считается бессрочным (как и уровень 3)
    "default_level2_duration_seconds": None, # Дефолтный срок при пропуске

  # Пороги автонаказаний по накопленным ОЧКАМ
    # action: "role" (выдать роль) | "timeout" (тайм-аут) | "kick" | "ban"
    "punishments": [], # одноразовые действия

  # ЖИВЫЕ ОГРАНИЧЕНИЯ ПО ОЧКАМ постоянные действие
    # проверка "хватает ли сейчас очков для флага"
    # каждый ког (анкета/предложения/войсы/автомодерация) спрашивает через get_active_flags(), можно ли участнику сделать то или иное действие. Как только очки падают (варн истёк/сняли) — ограничение снимается само
    # Доступные флаги:
    #   no_anketa — запрет создавать анкеты
    #   no_suggestion_create — запрет создавать предложения
    #   no_suggestion_vote — запрет голосовать за предложения
    #   no_voice_create — запрет создавать временные голосовые комнаты
    #   voice_join_invite_only — нельзя попасть в комнату через "распределитель",только по личному приглашению владельца
    #   no_voice_speak — сервер-мут при заходе в любой голосовой канал
    #   no_reactions / no_mentions / no_links / no_images — автомодерация
    #   read_only — вообще нельзя писать в обычных чатах
    "restrictions": [
        # {"points": 30, "flag": "no_anketa"},
        # {"points": 23, "flag": "no_suggestion_create"},
        # {"points": 17, "flag": "no_suggestion_vote"},
        # {"points": 22, "flag": "no_voice_create"},
        # {"points": 24, "flag": "voice_join_invite_only"},
        # {"points": 25, "flag": "no_voice_speak"},
        # {"points": 4,  "flag": "no_reactions"},
        # {"points": 5,  "flag": "no_mentions"},
        # {"points": 11, "flag": "no_images"},
        # {"points": 13, "flag": "no_links"},
        # {"points": 30, "flag": "read_only"},
    ],

    # Кулдаун на создание анкеты растёт по очкам (берётся САМЫЙ БОЛЬШОЙ
    # подходящий порог). Складывается с обычным cooldown_seconds анкеты —
    # действует какой из двух больше в моменте.
    "anketa_cooldown_tiers": [
        # {"points": 10, "seconds": 600},
        # {"points": 14, "seconds": 1200},
        # {"points": 18, "seconds": 2400},
        # {"points": 22, "seconds": 3600},
        # {"points": 27, "seconds": 10800},
    ],

    # Мягкий slowmode на стороне бота (не настоящий Discord slowmode —
    # тот общий на канал, а не персональный). Лишние сообщения быстрее
    # интервала просто удаляются. Тоже "самый большой подходящий порог".
    "soft_slowmode_tiers": [
        # {"points": 3, "seconds": 5},
        # {"points": 6, "seconds": 10},
        # {"points": 9, "seconds": 20},
        # {"points": 12, "seconds": 40},
        # {"points": 15, "seconds": 90},
        # {"points": 21, "seconds": 180},
    ],
}
MODERATION_CONFIGS = { 
  1518979351084011572: {
    "log_channel_id": 1518991549365751858,
    "soft_slowmode_tiers": [
      {"points": 5, "seconds": 5},
      {"points": 10, "seconds": 10},
      {"points": 15, "seconds": 20},
      {"points": 20, "seconds": 40},
      {"points": 25, "seconds": 90},
      {"points": 30, "seconds": 180},
    ],
    "anketa_cooldown_tiers": [
      {"points": 10, "seconds": 600},
      {"points": 15, "seconds": 1200},
      {"points": 20, "seconds": 2400},
      {"points": 25, "seconds": 3600},
      {"points": 30, "seconds": 10800},
    ],
    "restrictions": [
      {"points": 40, "flag": "no_anketa"},
      {"points": 30, "flag": "no_suggestion_create"},
      {"points": 35, "flag": "no_suggestion_vote"},
      {"points": 50, "flag": "no_voice_create"},
      {"points": 40, "flag": "voice_join_invite_only"},
      {"points": 45, "flag": "no_voice_speak"},
      {"points": 30,  "flag": "no_reactions"},
      {"points": 20,  "flag": "no_mentions"},
      {"points": 30, "flag": "no_images"},
      {"points": 25, "flag": "no_links"},
      {"points": 55, "flag": "read_only"},
    ],
    "punishments": [],
    "role_permissions": [
      {
        "role_id": 1519951628562727085,
        "commands": {
          "warn": {"levels": [1, 2, 3], "cooldown_seconds": 0},
          "mute": {"cooldown_seconds": 0},
          "kick": {"cooldown_seconds": 0},
          "ban": {"cooldown_seconds": 0},
          "clear": {"cooldown_seconds": 0},
          "re": {"cooldown_seconds": 0},
          "warnings": {"cooldown_seconds": 0},
          "unwarn": {"cooldown_seconds": 0},
        },
      },
      {
        "role_id": 1519951870884577410,
        "commands": {
          "warn": {"levels": [1, 2], "cooldown_seconds": 900},
          "mute": {"cooldown_seconds": 1800},
          "warnings": {"cooldown_seconds": 0},
          "unwarn": {"cooldown_seconds": 0},
        },
      },
      {
        "role_id": 1528955910649676009,
        "commands": {
          "warn": {"levels": [1], "cooldown_seconds": 1800},
          "warnings": {"cooldown_seconds": 0},
          "unwarn": {"cooldown_seconds": 0},
        },
      },
    ],
     },
}
# ========== КОНФИГ ПРИВЕТСТВИЙ / ПРОЩАНИЙ ==========
# Плейсхолдеры в тексте: {mention} — упоминание, {user} — имя без упоминания, {server} — название сервера, {member_count} — текущее число участников.
DEFAULT_GREETINGS_CONFIG = {
    "welcome_enabled": False,
    "welcome_channel_id": None,
    "welcome_title": "👋 Добро пожаловать!",
    "welcome_description": "Привет, {mention}! Рады видеть тебя на **{server}**.\nТы у нас участник(ца) №{member_count}.",
    "welcome_color": 0x57F287,
    "welcome_image": None,# URL баннера (широкая картинка снизу embed'а)
    "welcome_show_avatar": True,# показывать аватар нового участника (thumbnail)

    "farewell_enabled": False,
    "farewell_channel_id": None,# если не указать — используется welcome_channel_id
    "farewell_title": "👋 До встречи",
    "farewell_description": "**{user}** покинул(а) сервер. Теперь нас {member_count}.",
    "farewell_color": 0xED4245,

    "auto_role_id": None,# роль, которая выдаётся автоматически при входе (None — не выдавать)

    "boost_enabled": False,
    "boost_channel_id": None,# если не указать — используется welcome_channel_id
    "boost_message": "{mention} только что бустнул(а) сервер! Спасибо огромное",
    "boost_color": 0xF47FFF,
}
GREETINGS_CONFIGS = { 
  1518979351084011572: {
    "welcome_enabled": True,
    "welcome_channel_id": 1520816004786290958,
    "welcome_title": "Добро пожаловать! <a:Welcome:1528705986062454784>",
    "welcome_description": "Привет, {mention}! Рады видеть тебя на **{server}**.\nТы у нас участник(ца) №{member_count}.",
    "welcome_color": 0xD82318,
    "welcome_image": "https://pin.it/65MFeCE5N",# URL баннера (широкая картинка снизу embed'а)
    "welcome_show_avatar": True, 
# ==============================
    "farewell_enabled": True,
    "farewell_channel_id": 1520811381384024134,# если не указать — используется welcome_channel_id
    "farewell_title": "До встречи, <a:1000133246:1528706765166743682>",
    "farewell_description": "**{user}** покинул(а) сервер. Теперь нас {member_count}.",
    "farewell_color": 0xED4245,
#===============================
    "boost_enabled": True,
    "boost_channel_id": 1518991549365751858,# если не указать — используется welcome_channel_id
    "boost_message": "{mention} только что бустнул(а) сервер! Спасибо огромное",
    "boost_color": 0xF47FFF,

# роль, которая выдаётся автоматически при входе
    "auto_role_id": 1519952475178668062
  },
}


def get_greetings_config(guild_id: int) -> dict:
    override = GREETINGS_CONFIGS.get(guild_id, {})
    config = _deep_merge(DEFAULT_GREETINGS_CONFIG, override)
    config["guild_id"] = guild_id
    return config

# ========== КОНФИГ РЕКЛАМНЫХ ОБЪЯВЛЕНИЙ ==========
# Периодически рассылает embed по каналам — как в текстовый чат КАЖДОЙ
# активной временной войс-комнаты, так и в отдельно перечисленные каналы
# (например туда, где висит анкета). Объявления из "ads" ротируются по кругу.
DEFAULT_ADVERTISEMENT_CONFIG = {
    "enabled": False,

    # Мгновенная реклама: появляется в КАЖДОЙ новой временной войс-комнате
    # сразу при её создании (один раз на комнату, не переспамливает потом).
    "post_on_voice_create": True,

    # Периодическая рассылка: раз в interval_seconds — в конкретные каналы
    # (например туда, где висит анкета или предложения). Если channel_ids
    # пуст — периодической рассылки просто не будет.
    "interval_seconds": 3600,
    "channel_ids": [],

    # Объявления ротируются по кругу (если их несколько, каждая рассылка/
    # каждая новая комната получает следующее по очереди).
    "ads": [
        # {
        #     "title": "🎉 Загляните в раздел предложений",
        #     "description": "Есть идея, как улучшить сервер? Поделитесь — обсудим вместе!",
        #     "color": 0x5865F2,
        #     "image": None,
        #     "footer": None,
        # },
    ],
}
ADVERTISEMENT_CONFIGS = {
    # 1518979351084011572: {
    #     "enabled": True,
    #     "post_on_voice_create": True,
    #     "interval_seconds": 1800,
    #     "channel_ids": [0],   # например ID канала с анкетой
    #     "ads": [
    #         {"title": "💡 Есть идея?", "description": "Загляните в #предложения!", "color": 0x5865F2},
    #     ],
    # },
}


def get_advertisement_config(guild_id: int) -> dict:
    override = ADVERTISEMENT_CONFIGS.get(guild_id, {})
    config = _deep_merge(DEFAULT_ADVERTISEMENT_CONFIG, override)
    config["guild_id"] = guild_id
    return config

# ========== "МЕДИА-ТОЛЬКО" КАНАЛЫ + АВТО-ВЕТКИ (cogs/media_only.py) ==========
# В этих каналах у обычных участников (не админов) удаляется всё, что не
# укладывается в разрешённые типы контента. Голый текст без вложений
# удаляется ВСЕГДА, вне зависимости от настроек ниже.
#
# Формат: {ID_канала: {"images": bool, "videos": bool, "files": bool,
#                        "polls": bool, "links": bool, "auto_thread": bool}}
# Ключ, который не указали — считается разрешённым по умолчанию (кроме
# auto_thread — тот по умолчанию выключен), то есть для типов контента
# достаточно перечислить только то, что хотите ЗАПРЕТИТЬ.
#
# auto_thread: True — под каждым сообщением, которое ПРОШЛО фильтр (не
# удалено), сама открывается ветка-обсуждение. Название ветки — начало
# текста сообщения, либо "Обсуждение — Имя", если сообщение без текста.
MEDIA_ONLY_CHANNELS = {
    # 1518979351855501429: {"files": False, "auto_thread": True},                    # можно всё, кроме файлов; под каждым — своя ветка
    # 1518979351855501999: {"images": True, "polls": True, "videos": False, "files": False},  # только картинки и опросы
    # 1518979351855502222: {"videos": True, "images": False, "polls": False},        # только видео, ветки не нужны
    # 1518979351855502333: {"links": True, "images": False, "files": False, "polls": False},  # только ссылки
}

# ========== КОНФИГ АНТИЧИТА (мат/спам/инвайты) ==========
# Срабатывания выдают НАСТОЯЩЕЕ предупреждение через ту же систему, что и
# команда /warn (очки, сроки, автонаказания, лог) — см. cogs/automod.py.
DEFAULT_AUTOMOD_CONFIG = {
    "enabled": False,
    "ignore_channels": [],   # каналы, где фильтр не работает (ID)
    "read_only_exempt_channels": [],  # каналы, где read_only (флаг из restrictions) не действует — например поддержка
    "ignore_roles": [],      # роли, которые не проверяются — например модерация (ID)

    # Запрещённые слова — простое совпадение подстроки, без учёта регистра.
    # Основной список — в отдельном файле banned_words.py (удобно пополнять,
    # не трогая этот конфиг). Здесь можно добавить ТОЛЬКО для этого сервера.
    "extra_banned_words": [],
    "banned_word_delete": True,
    "banned_word_warn_level": 1,                  # 1/2/3 — как у /warn
    "banned_word_warn_duration_seconds": 3600,    # обязателен для уровня 1
    "banned_word_warn_reason": "Автомодерация: запрещённое слово",

    # Спам: N сообщений за M секунд от одного участника подряд
    "spam_enabled": False,
    "spam_message_threshold": 5,
    "spam_interval_seconds": 5,
    "spam_delete": True,
    "spam_warn_level": 1,
    "spam_warn_duration_seconds": 1800,
    "spam_warn_reason": "Автомодерация: спам сообщениями",

    # Инвайты на сторонние Discord-серверы
    "invite_filter_enabled": False,
    "invite_delete": True,
    "invite_warn_level": 1,
    "invite_warn_duration_seconds": 3600,
    "invite_warn_reason": "Автомодерация: приглашение на сторонний сервер",
}

AUTOMOD_CONFIGS = {
    # 1518979351084011572: {
    #     "enabled": True,
    #     "extra_banned_words": ["слово1", "слово2"],  # доп. слова только для этого сервера
    #     "spam_enabled": True,
    #     "invite_filter_enabled": True,
    #     "ignore_roles": [1519951628562727085],  # модерацию фильтр не трогает
    # },
}


def get_automod_config(guild_id: int) -> dict:
    override = AUTOMOD_CONFIGS.get(guild_id, {})
    config = _deep_merge(DEFAULT_AUTOMOD_CONFIG, override)
    config["guild_id"] = guild_id
    return config

"""
Конфигурация временных голосовых каналов.

Как это работает:
- DEFAULT_VOICE_CONFIG — базовые настройки "по умолчанию" для любого сервера.
- VOICE_CONFIGS[guild_id] — настройки конкретного сервера. Можно указать
  ТОЛЬКО то, что отличается от дефолта (остальное подтянется само благодаря
  глубокому слиянию словарей — см. _deep_merge / get_voice_config).

Пример: если на сервере нужен только другой цвет embed'а и свои каналы —
не нужно копировать весь embed целиком, достаточно:

    "embed": {"color": 0xFF0000}

МУЛЬТИКАТЕГОРИЙНОСТЬ И ИНТЕРЕСЫ:
У Discord жёсткий лимит — 50 каналов в одной категории. На крупном сервере
одна категория забьётся быстро, поэтому комнаты живут в ПУЛЕ категорий
("categories"): бот сам находит первую категорию с местом и создаёт комнату
там. Входов в этот пул может быть несколько ("creators") — по одному на
каждый интерес/тему, чтобы люди сразу попадали в тематическую комнату,
а не в общий котёл.
"""

import copy

# ========== БАЗОВЫЙ КОНФИГ ==========
DEFAULT_VOICE_CONFIG = {
    "guild_id": None,
    "setting_channel": None,     # канал, где висит панель управления
    "categories": [], #пуль категорий

    # ---------- ВХОДЫ ПО ИНТЕРЕСАМ ----------
    # Каждый элемент — отдельный голосовой канал-"вход". Зайдя в него,
    # человек получает СВОЮ комнату с соответствующей темой/названием.
    # Можно сделать хоть 10 входов на разные интересы — по одному на каждый.
    #   channel_id:    ID канала-входа в Discord
    #   label:         как называется тема (для топика комнаты/статистики)
    #   name_template: шаблон имени комнаты, {user} = display_name автора
    #   categories:    (необязательно) свой пул категорий именно для этого
    #                  интереса — если не указать, используется общий "categories"
    "creators": [],

    # Канал-"распределитель": зашедшего сюда бот сразу перекидывает
    # в чью-то уже заселённую комнату (а не создаёт новую).
    "distributor_channel": None,
    "distributor_strategy": "least_members",  # "least_members" | "random"
    "distributor_ignore_full": True,          # не кидать в комнаты, где уже достигнут лимит
    "distributor_ignore_locked": True,        # не кидать в комнаты с закрытым доступом (ДОСТУП)

    "creation_cooldown_seconds": 5,  # антиспам: не чаще раза в N секунд на человека

    # ---------- EMBED ПАНЕЛИ ----------
    # Тут можно настроить абсолютно всё, что показывает embed панели.
    "embed": {
        "title": "<:Settings:1527246119967658034> Управление приватным каналом",
        "description": (
            "Используйте кнопки ниже для настройки параметров приватного канала.\n"
            "Функции доступны только при наличии созданного приватного канала."
        ),
        "color": 0x5865F2,
        "thumbnail": None,       # URL картинки-превью (справа сверху)
        "image": None,           # URL большой картинки (снизу embed'а)
        "author_name": None,
        "author_icon": None,
        "footer_text": None,
        "footer_icon": None,
        "timestamp": False,      # показывать ли текущее время в footer'е
        # Список "эмодзи — `что делает`" под описанием строится САМ из
        # guide_text каждой кнопки ниже — выключить автогенерацию:
        "auto_guide": True,
        # Доп. поля embed'а: [{"name": "...", "value": "...", "inline": True}, ...]
        "fields": [],
    },

    # Предустановленные названия для выбора ПРЕСЕТОВ
    "preset_names": [
        "Steam игры",
        "Roblox режимы",
        "Общение",
        "Музыкальная",
        "Стрим",
    ],

    # ---------- КНОПКИ ПАНЕЛИ ----------
    # style: "primary" | "secondary" | "success" | "danger"
    # row: номер ряда (0-4), максимум 5 кнопок в ряду.
    # emoji: иконка кнопки. label: текст рядом с иконкой — оставьте None/""
    #        для кнопки-иконки без подписи (как на референсе).
    # guide_text: короткое описание для автогенерируемой памятки в embed'е.
    # enabled: False — кнопка временно не показывается (проще, чем удалять).
    "buttons": [
    {
        "emoji": "<:Name_set:1527246117912182824>",
        "guide_text": "изменить название комнаты",
        "style": "secondary", "acemojition": "name",
        "action": "name",
        "row": 0
    },
    {
        "emoji": "<:Lemit:1527246124694638652>",
        "guide_text": "установить лимит пользователей",
        "style": "secondary",
        "action": "limit",
        "row": 0
    },
    {
        "emoji": "<:Access:1527246129463296102>",
        "guide_text": "закрыть/открыть доступ в комнату",
        "style": "secondary",
        "action": "access",
        "row": 0
    },
    {
        "emoji": "<:View:1527246131187421214>",
        "guide_text": "скрыть/раскрыть комнату для всех",
        "style": "secondary",
        "action": "hide",
        "row": 0
    },
    {
        "emoji": "<:User_access:1527246127374536837>",
        "guide_text": "забрать/выдать доступ к комнате пользователю",
        "style": "secondary",
        "action": "toggle_access",
        "row": 0
    },

    {
        "emoji": "<:Voice:1527246134521888788>",
        "guide_text": "забрать/выдать право говорить пользователю",
        "style": "secondary",
        "action": "toggle_speak",
        "row": 1
    },
    {
        "emoji": "<:Kick:1527246132529463396>",
        "guide_text": "выгнать пользователя из комнаты",
        "style": "secondary",
        "action": "kick",
        "row": 1
    },
    {
        "emoji": "<:Clear:1527246153694056628>",
        "guide_text": "сбросить права пользователю",
        "style": "secondary",
        "action": "reset_user",
        "row": 1
    },
    {
        "emoji": "<:Leader:1527246157137580073>",
        "guide_text": "сделать пользователя новым владельцем",
        "style": "secondary",
        "action": "transfer",
        "row": 1
    },
    {
        "emoji": "<:Info:1527246155363389470>",
        "guide_text": "информация о комнате",
        "style": "secondary",
        "action": "status",
        "row": 1
    },
],
}
VOICE_CONFIGS = {
    1518979351084011572: {
        "guild_id": 1518979351084011572,
        "setting_channel": 1524452997571149877,
        "distributor_channel": 1527927736352374804,
        "distributor_strategy": "random",
        "categories": [
            1518979351855501429,
            1525529593031819264,  # вторая категория про запас
            1525529690754908271,  # третья про запас
        ],

        # Несколько входов по интересам вместо одного общего.
        # ЗАМЕНИТЕ channel_id на реальные ID ваших голосовых каналов-входов.
        "creators": [
            {
                "channel_id": 1524453284847419413,
                "label": "Общение",
                "name_template": "voise {user}",
            }
        ],
        # "distributor_channel": 1111111111111111111,  # раскомментируйте и укажите ID канала-распределителя
        "preset_names": [
          "Steam",
          "Roblox",
          "Общение",
          "Музыка"
        ],
        "inline": True,
        "embed": {
          "color":0xD82318
        #     "footer_text": "Roblox RU",
        #     "thumbnail": "https://example.com/icon.png",
        },
    }
}


def _deep_merge(base: dict, override: dict) -> dict:
    """Рекурсивно накладывает override поверх base, не трогая оригиналы."""
    result = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def get_voice_config(guild_id: int) -> dict:
    """Возвращает полный конфиг для сервера: дефолт + персональные правки."""
    override = VOICE_CONFIGS.get(guild_id, {})
    config = _deep_merge(DEFAULT_VOICE_CONFIG, override)
    config["guild_id"] = guild_id
    return config


  
# ========== ФУНКЦИИ ДЛЯ КОНФИГОВ ==========
def get_anketa_config(channel_id):
    config = ANKETA_CONFIGS.get(channel_id, {})
    merged = DEFAULT_ANKETA_CONFIG.copy()
    merged.update(config)
    return merged

def get_ticket_config(channel_id):
    config = TICKET_CONFIGS.get(channel_id, {})
    merged = DEFAULT_TICKET_CONFIG.copy()
    merged.update(config)
    return merged

def get_suggestion_config(channel_id):
    config = SUGGESTION_CONFIGS.get(channel_id, {})
    merged = DEFAULT_SUGGESTION_CONFIG.copy()
    merged.update(config)
    return merged

def get_moderation_config(guild_id: int) -> dict:
    """Дефолт + персональные правки. Используется deep-merge (как у войсов),
    чтобы можно было переопределить один вложенный ключ (например только
    punishments), не переписывая весь конфиг заново."""
    override = MODERATION_CONFIGS.get(guild_id, {})
    config = _deep_merge(DEFAULT_MODERATION_CONFIG, override)
    config["guild_id"] = guild_id
    return config

# ========== ГЛОБАЛЬНЫЕ ПЕРЕМЕННЫЕ ==========
button_messages = {}
ticket_messages = {}
user_tickets = {}

# ========== ФУНКЦИЯ НАСТРОЙКИ ВСЕХ ПАНЕЛЕЙ (вызывается из on_ready) ==========
async def _setup_channel_panels(channel_id: int):
    """Настраивает анкету/тикет для одного канала. Вынесено в отдельную
    корутину, чтобы каналы обрабатывались параллельно (asyncio.gather),
    а не по очереди — иначе медленный канал в начале списка задерживал
    отправку панели во всех остальных, включая анкету."""
    channel = bot.get_channel(channel_id)
    if not channel:
        print(f"<:Other_problem:1528536802720350370> Канал {channel_id} не найден!")
        return

    has_anketa = channel_id in ANKETA_CONFIGS
    has_ticket = channel_id in TICKET_CONFIGS

    # ---- ОБРАБОТКА АНКЕТЫ ----
    if has_anketa:
        anketa_cog = bot.get_cog("AnketaCog")
        if anketa_cog:
            deleted = await anketa_cog.clean_old_anketa_panels(channel)
            print(f"🧹 Удалено {deleted} старых панелей анкеты в канале #{channel.name}")
            await anketa_cog.send_anketa_panel(channel)
            print(f"✅ Анкета (кнопка от бота) отправлена в канал #{channel.name}")

    # ---- ОБРАБОТКА ТИКЕТА ----
    if has_ticket:
        ticket_cog = bot.get_cog("TicketsCog")
        if ticket_cog:
            # send_ticket_panel сам удаляет старую панель по сохранённому ID
            # (см. cogs/tickets.py) — полный purge канала тут не нужен и был
            # самой медленной частью всего процесса запуска.
            await ticket_cog.send_ticket_panel(channel)
            print(f"✅ Панель тикетов отправлена в канал #{channel.name}")


    # ---- ОБРАБОТКА ПАНЕЛИ ПРЕДЛОЖЕНИЙ ----
    if channel_id in SUGGESTION_CONFIGS:
        suggestions_cog = bot.get_cog("SuggestionsCog")
        if suggestions_cog:
            deleted = await suggestions_cog.clean_old_suggestion_panels(channel)
            print(f"🧹 Удалено {deleted} старых панелей предложений в канале #{channel.name}")
            await suggestions_cog.send_suggestion_panel(channel)
            print(f"✅ Панель предложений отправлена в канал #{channel.name}")


async def setup_all_panels():
    """Параллельно обрабатывает все каналы из конфигов анкет/тикетов/предложений."""
    all_channel_ids = set(ANKETA_CONFIGS.keys()) | set(TICKET_CONFIGS.keys()) | set(SUGGESTION_CONFIGS.keys())
    await asyncio.gather(*(_setup_channel_panels(cid) for cid in all_channel_ids))

# ========== ЗАГРУЗКА КОГОВ И ЗАПУСК ==========
@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError):
    # На случай, если когда-нибудь снова появятся префиксные команды —
    # без этого обработчика ошибка падает трейсбеком в консоль, а
    # пользователь не получает вообще никакого ответа.
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("<:Other_problem:1528536802720350370> У вас недостаточно прав для этой команды.", delete_after=5)
    elif isinstance(error, commands.CommandNotFound):
        pass  # не спамим на опечатки в командах
    else:
        print(f"⚠️ Ошибка команды {ctx.command}: {error}")
        await ctx.send("<:Other_problem:1528536802720350370> Произошла ошибка при выполнении команды.", delete_after=5)


@bot.event
async def on_slash_command_error(inter: disnake.ApplicationCommandInteraction, error: commands.CommandError):
    # Все команды бота теперь слэш-команды — без этого обработчика
    # необработанное исключение внутри команды оставляет интеракцию без
    # ответа (для пользователя это выглядит как зависшая кнопка/команда),
    # а сама ошибка видна только в консоли.
    print(f"⚠️ Ошибка слэш-команды /{inter.application_command.name}: {error}")
    message = "<:Other_problem:1528536802720350370> Произошла ошибка при выполнении команды."
    if isinstance(error, commands.MissingPermissions):
        message = "<:Other_problem:1528536802720350370> У вас недостаточно прав для этой команды."
    try:
        if inter.response.is_done():
            await inter.followup.send(message, ephemeral=True)
        else:
            await inter.response.send_message(message, ephemeral=True)
    except disnake.HTTPException:
        pass  # интеракция уже протухла — ничего не поделать, ошибка всё равно в логе


_panels_initialized = False  # on_ready может сработать больше одного раза за
                              # сессию (например, при переподключении к Discord) —
                              # без этого флага setup_all_panels() отрабатывал бы
                              # каждый раз заново, дублируя панели в каналах.


@bot.event
async def on_ready():
    global _panels_initialized
    print(f"✅ Бот {bot.user} запущен!")
    if _panels_initialized:
        print("ℹ️ on_ready сработал повторно (переподключение) — панели уже настроены, пропускаем.")
        return
    _panels_initialized = True
    # Вызываем настройку всех панелей
    await setup_all_panels()
    print("✅ Все панели настроены!")

if __name__ == "__main__":
    bot.load_extension("cogs.anketa")
    bot.load_extension("cogs.tickets")
    bot.load_extension("cogs.voice")
    bot.load_extension("cogs.suggestions")
    bot.load_extension("cogs.moderation")
    bot.load_extension("cogs.automod")
    bot.load_extension("cogs.greetings")
    bot.load_extension("cogs.ads")
    bot.load_extension("cogs.utility")
    bot.load_extension("cogs.backup")
    bot.load_extension("cogs.media_only")
    bot.run(TOKEN)