"""
Персистентное хранилище бота (SQLite, один файл, без внешней БД).

Изначально тут жили только временные голосовые каналы, но раздутие в
памяти — общая проблема любого состояния, которое должно пережить
рестарт бота, поэтому сюда же добавлены открытые тикеты: без этого
кнопка "Закрыть тикет" в уже созданных тикет-каналах переставала
отвечать после каждого рестарта бота (сама View создаётся только один
раз при создании тикета и никогда не переотправляется).
"""

import asyncio
import time

import aiosqlite

_conn: aiosqlite.Connection | None = None
_write_lock = asyncio.Lock()  # sqlite не любит параллельную запись из разных корутин
_init_lock = asyncio.Lock()   # защита init() от гонки — теперь его вызывают 3 кога при старте


DB_PATH = "voice_channels.db"


async def init(db_path: str = DB_PATH) -> None:
    global _conn
    async with _init_lock:
        if _conn is not None:
            return  # уже инициализировано другим когом, который успел раньше
        _conn = await aiosqlite.connect(db_path)
        await _conn.execute("PRAGMA journal_mode=WAL;")
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS owners (
                guild_id   INTEGER NOT NULL,
                owner_id   INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                PRIMARY KEY (guild_id, owner_id)
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS blacklist (
                guild_id  INTEGER NOT NULL,
                owner_id  INTEGER NOT NULL,
                banned_id INTEGER NOT NULL,
                PRIMARY KEY (guild_id, owner_id, banned_id)
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS panels (
                guild_id   INTEGER PRIMARY KEY,
                message_id INTEGER NOT NULL
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS channel_panels (
                channel_id INTEGER PRIMARY KEY,
                message_id INTEGER NOT NULL
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS tickets (
                guild_id           INTEGER NOT NULL,
                ticket_channel_id  INTEGER PRIMARY KEY,
                author_id          INTEGER NOT NULL,
                source_channel_id  INTEGER NOT NULL,
                label              TEXT,
                close_style        TEXT,
                close_emoji        TEXT
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS ticket_counters (
                source_channel_id INTEGER PRIMARY KEY,
                value             INTEGER NOT NULL DEFAULT 0
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS suggestions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id    INTEGER NOT NULL,
                channel_id  INTEGER NOT NULL,
                message_id  INTEGER,
                author_id   INTEGER NOT NULL,
                text        TEXT NOT NULL,
                status      TEXT NOT NULL DEFAULT 'pending',
                reason      TEXT,
                created_at  REAL
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS suggestion_votes (
                suggestion_id INTEGER NOT NULL,
                user_id       INTEGER NOT NULL,
                value         INTEGER NOT NULL,
                PRIMARY KEY (suggestion_id, user_id)
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS suggestion_cooldowns (
                guild_id          INTEGER NOT NULL,
                user_id           INTEGER NOT NULL,
                last_submitted_at REAL NOT NULL,
                PRIMARY KEY (guild_id, user_id)
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS warnings (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id     INTEGER NOT NULL,
                user_id      INTEGER NOT NULL,
                moderator_id INTEGER NOT NULL,
                level        INTEGER NOT NULL,
                points       INTEGER NOT NULL,
                reason       TEXT,
                created_at   REAL NOT NULL,
                expires_at   REAL,
                active       INTEGER NOT NULL DEFAULT 1
            )
        """)
        await _conn.execute("""
            CREATE TABLE IF NOT EXISTS command_cooldowns (
                guild_id  INTEGER NOT NULL,
                user_id   INTEGER NOT NULL,
                command   TEXT NOT NULL,
                last_used REAL NOT NULL,
                PRIMARY KEY (guild_id, user_id, command)
            )
        """)

        # Миграция: created_at добавили в suggestions уже после того, как у
        # части пользователей база была создана без него — CREATE TABLE IF
        # NOT EXISTS не добавляет колонки в уже существующую таблицу, нужно
        # руками. Если колонка уже есть — SQLite вернёт ошибку, просто её
        # игнорируем (тут переносить нечего — старые предложения глухо
        # покажут пустое время создания, что нормально).
        try:
            await _conn.execute("ALTER TABLE suggestions ADD COLUMN created_at REAL")
        except Exception:
            pass  # колонка уже существует — это ожидаемо на большинстве запусков

        await _conn.commit()


async def close() -> None:
    if _conn:
        await _conn.close()


# ---------------- владельцы комнат ----------------

async def set_owner(guild_id: int, owner_id: int, channel_id: int) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO owners (guild_id, owner_id, channel_id) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id, owner_id) DO UPDATE SET channel_id=excluded.channel_id",
            (guild_id, owner_id, channel_id),
        )
        await _conn.commit()


async def remove_owner(guild_id: int, owner_id: int) -> None:
    async with _write_lock:
        await _conn.execute("DELETE FROM owners WHERE guild_id=? AND owner_id=?", (guild_id, owner_id))
        await _conn.commit()


async def load_all_owners(guild_id: int) -> list[tuple[int, int]]:
    """Возвращает [(owner_id, channel_id), ...] — используется при старте бота."""
    async with _conn.execute(
        "SELECT owner_id, channel_id FROM owners WHERE guild_id=?", (guild_id,)
    ) as cur:
        return await cur.fetchall()


# ---------------- чёрный список ----------------
# Привязан к владельцу, а не к конкретному каналу: комната удаляется и
# пересоздаётся заново каждый раз, а бан должен "переезжать" вместе с
# владельцем в его новую комнату.

async def ban(guild_id: int, owner_id: int, banned_id: int) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT OR IGNORE INTO blacklist (guild_id, owner_id, banned_id) VALUES (?, ?, ?)",
            (guild_id, owner_id, banned_id),
        )
        await _conn.commit()


async def unban(guild_id: int, owner_id: int, banned_id: int) -> None:
    async with _write_lock:
        await _conn.execute(
            "DELETE FROM blacklist WHERE guild_id=? AND owner_id=? AND banned_id=?",
            (guild_id, owner_id, banned_id),
        )
        await _conn.commit()


async def get_blacklist(guild_id: int, owner_id: int) -> list[int]:
    async with _conn.execute(
        "SELECT banned_id FROM blacklist WHERE guild_id=? AND owner_id=?", (guild_id, owner_id)
    ) as cur:
        rows = await cur.fetchall()
        return [r[0] for r in rows]


# ---------------- панель ----------------

async def save_panel(guild_id: int, message_id: int) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO panels (guild_id, message_id) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET message_id=excluded.message_id",
            (guild_id, message_id),
        )
        await _conn.commit()


async def get_panel(guild_id: int) -> int | None:
    async with _conn.execute("SELECT message_id FROM panels WHERE guild_id=?", (guild_id,)) as cur:
        row = await cur.fetchone()
        return row[0] if row else None


# ---------------- тикеты ----------------
# Открытый тикет живёт часами/днями, и его кнопка "Закрыть" должна
# отвечать даже после рестарта бота — для этого при старте бот заново
# регистрирует View для каждого открытого тикета (см. TicketsCog.initialize).

async def save_ticket(guild_id: int, ticket_channel_id: int, author_id: int, source_channel_id: int,
                       label: str, close_style: str, close_emoji: str | None) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO tickets (guild_id, ticket_channel_id, author_id, source_channel_id, "
            "label, close_style, close_emoji) VALUES (?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(ticket_channel_id) DO UPDATE SET author_id=excluded.author_id",
            (guild_id, ticket_channel_id, author_id, source_channel_id, label, close_style, close_emoji),
        )
        await _conn.commit()


async def remove_ticket(ticket_channel_id: int) -> None:
    async with _write_lock:
        await _conn.execute("DELETE FROM tickets WHERE ticket_channel_id=?", (ticket_channel_id,))
        await _conn.commit()


async def load_all_tickets() -> list[tuple[int, int, int, int, str, str, str | None]]:
    """(guild_id, ticket_channel_id, author_id, source_channel_id, label, close_style, close_emoji)"""
    async with _conn.execute(
        "SELECT guild_id, ticket_channel_id, author_id, source_channel_id, label, close_style, close_emoji "
        "FROM tickets"
    ) as cur:
        return await cur.fetchall()


async def next_ticket_number(source_channel_id: int) -> int:
    """Атомарно увеличивает и возвращает счётчик тикетов для канала-конфига."""
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO ticket_counters (source_channel_id, value) VALUES (?, 1) "
            "ON CONFLICT(source_channel_id) DO UPDATE SET value = value + 1",
            (source_channel_id,),
        )
        await _conn.commit()
        async with _conn.execute(
            "SELECT value FROM ticket_counters WHERE source_channel_id=?", (source_channel_id,)
        ) as cur:
            row = await cur.fetchone()
            return row[0]


# ---------------- предложения ----------------
# Голоса и статус рассмотрения хранятся в БД, а не в памяти:
#   1) голос "один человек — один голос" должен переживать рестарт бота;
#   2) кнопки голосования/рассмотрения — как и у тикетов — регистрируются
#      заново при старте, иначе перестают отвечать после рестарта.

async def create_suggestion(guild_id: int, channel_id: int, author_id: int, text: str) -> int:
    async with _write_lock:
        cur = await _conn.execute(
            "INSERT INTO suggestions (guild_id, channel_id, author_id, text, created_at) VALUES (?, ?, ?, ?, ?)",
            (guild_id, channel_id, author_id, text, time.time()),
        )
        await _conn.commit()
        return cur.lastrowid


async def get_last_suggestion_time(guild_id: int, user_id: int) -> float | None:
    """Unix-время последнего предложения этого юзера — храним в БД, а не в
    памяти, иначе рестарт бота сбрасывал бы суточный кулдаун."""
    async with _conn.execute(
        "SELECT last_submitted_at FROM suggestion_cooldowns WHERE guild_id=? AND user_id=?", (guild_id, user_id)
    ) as cur:
        row = await cur.fetchone()
        return row[0] if row else None


async def set_last_suggestion_time(guild_id: int, user_id: int, timestamp: float) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO suggestion_cooldowns (guild_id, user_id, last_submitted_at) VALUES (?, ?, ?) "
            "ON CONFLICT(guild_id, user_id) DO UPDATE SET last_submitted_at=excluded.last_submitted_at",
            (guild_id, user_id, timestamp),
        )
        await _conn.commit()


async def set_suggestion_message(suggestion_id: int, message_id: int) -> None:
    async with _write_lock:
        await _conn.execute("UPDATE suggestions SET message_id=? WHERE id=?", (message_id, suggestion_id))
        await _conn.commit()


async def set_suggestion_status(suggestion_id: int, status: str, reason: str | None = None) -> None:
    async with _write_lock:
        await _conn.execute(
            "UPDATE suggestions SET status=?, reason=? WHERE id=?", (status, reason, suggestion_id),
        )
        await _conn.commit()


async def get_suggestion(suggestion_id: int):
    """(id, guild_id, channel_id, message_id, author_id, text, status, reason, created_at) или None."""
    async with _conn.execute(
        "SELECT id, guild_id, channel_id, message_id, author_id, text, status, reason, created_at "
        "FROM suggestions WHERE id=?", (suggestion_id,),
    ) as cur:
        return await cur.fetchone()


async def load_open_suggestions() -> list[tuple[int, int, int, int]]:
    """(id, guild_id, channel_id, message_id) для уже отправленных предложений —
    используется, чтобы заново зарегистрировать кнопки после рестарта бота."""
    async with _conn.execute(
        "SELECT id, guild_id, channel_id, message_id FROM suggestions WHERE message_id IS NOT NULL"
    ) as cur:
        return await cur.fetchall()


async def cast_vote(suggestion_id: int, user_id: int, value: int) -> tuple[int, int]:
    """value: 1 = за, -1 = против. Повторный клик по тому же варианту снимает голос.
    Возвращает (голосов_за, голосов_против) после применения."""
    async with _write_lock:
        async with _conn.execute(
            "SELECT value FROM suggestion_votes WHERE suggestion_id=? AND user_id=?",
            (suggestion_id, user_id),
        ) as cur:
            existing = await cur.fetchone()
        if existing and existing[0] == value:
            await _conn.execute(
                "DELETE FROM suggestion_votes WHERE suggestion_id=? AND user_id=?",
                (suggestion_id, user_id),
            )
        else:
            await _conn.execute(
                "INSERT INTO suggestion_votes (suggestion_id, user_id, value) VALUES (?, ?, ?) "
                "ON CONFLICT(suggestion_id, user_id) DO UPDATE SET value=excluded.value",
                (suggestion_id, user_id, value),
            )
        await _conn.commit()
    return await get_vote_counts(suggestion_id)


async def get_vote_counts(suggestion_id: int) -> tuple[int, int]:
    async with _conn.execute(
        "SELECT "
        "SUM(CASE WHEN value=1 THEN 1 ELSE 0 END), "
        "SUM(CASE WHEN value=-1 THEN 1 ELSE 0 END) "
        "FROM suggestion_votes WHERE suggestion_id=?",
        (suggestion_id,),
    ) as cur:
        row = await cur.fetchone()
        up, down = row
        return up or 0, down or 0


# ---------------- предупреждения (warn) ----------------
# Уровень определяет только то, обязателен ли срок и как парсится команда —
# хранится просто как level 1/2/3. "active=0" — предупреждение снято
# вручную (unwarn) либо истёк срок (фоновая задача expire).

async def add_warning(guild_id: int, user_id: int, moderator_id: int, level: int,
                       points: int, reason: str, expires_at: float | None) -> int:
    async with _write_lock:
        cur = await _conn.execute(
            "INSERT INTO warnings (guild_id, user_id, moderator_id, level, points, reason, "
            "created_at, expires_at, active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)",
            (guild_id, user_id, moderator_id, level, points, reason, time.time(), expires_at),
        )
        await _conn.commit()
        return cur.lastrowid


async def get_active_warnings(guild_id: int, user_id: int):
    """(id, level, points, reason, created_at, expires_at) для активных предупреждений."""
    async with _conn.execute(
        "SELECT id, level, points, reason, created_at, expires_at FROM warnings "
        "WHERE guild_id=? AND user_id=? AND active=1 ORDER BY created_at",
        (guild_id, user_id),
    ) as cur:
        return await cur.fetchall()


async def get_total_points(guild_id: int, user_id: int) -> int:
    async with _conn.execute(
        "SELECT COALESCE(SUM(points), 0) FROM warnings WHERE guild_id=? AND user_id=? AND active=1",
        (guild_id, user_id),
    ) as cur:
        row = await cur.fetchone()
        return row[0] or 0


async def deactivate_warning(guild_id: int, warning_id: int) -> bool:
    """True, если запись реально была активна и её сняли (unwarn)."""
    async with _write_lock:
        cur = await _conn.execute(
            "UPDATE warnings SET active=0 WHERE id=? AND guild_id=? AND active=1", (warning_id, guild_id),
        )
        await _conn.commit()
        return cur.rowcount > 0


async def get_expired_warnings(now: float):
    """(id, guild_id, user_id) для предупреждений с истёкшим сроком — для фоновой задачи."""
    async with _conn.execute(
        "SELECT id, guild_id, user_id FROM warnings "
        "WHERE active=1 AND expires_at IS NOT NULL AND expires_at<=?",
        (now,),
    ) as cur:
        return await cur.fetchall()


async def expire_warning(warning_id: int) -> None:
    async with _write_lock:
        await _conn.execute("UPDATE warnings SET active=0 WHERE id=?", (warning_id,))
        await _conn.commit()


# ---------------- кулдауны команд модерации ----------------
# Персистентно (не в памяти), чтобы кулдаун "раз в 2 часа" не сбрасывался
# рестартом бота — иначе младшая модерация могла бы обходить лимит,
# просто дождавшись перезапуска.

async def get_command_cooldown(guild_id: int, user_id: int, command: str) -> float | None:
    async with _conn.execute(
        "SELECT last_used FROM command_cooldowns WHERE guild_id=? AND user_id=? AND command=?",
        (guild_id, user_id, command),
    ) as cur:
        row = await cur.fetchone()
        return row[0] if row else None


async def set_command_cooldown(guild_id: int, user_id: int, command: str, timestamp: float) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO command_cooldowns (guild_id, user_id, command, last_used) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(guild_id, user_id, command) DO UPDATE SET last_used=excluded.last_used",
            (guild_id, user_id, command, timestamp),
        )
        await _conn.commit()


# ---------------- лёгкая статистика для /stats ----------------
# Простые COUNT-запросы — дешёвые, без выборки данных целиком.

async def count_active_voice_rooms(guild_id: int) -> int:
    async with _conn.execute("SELECT COUNT(*) FROM owners WHERE guild_id=?", (guild_id,)) as cur:
        row = await cur.fetchone()
        return row[0] or 0


async def count_open_tickets(guild_id: int) -> int:
    async with _conn.execute("SELECT COUNT(*) FROM tickets WHERE guild_id=?", (guild_id,)) as cur:
        row = await cur.fetchone()
        return row[0] or 0


async def count_pending_suggestions(guild_id: int) -> int:
    async with _conn.execute(
        "SELECT COUNT(*) FROM suggestions WHERE guild_id=? AND status='pending'", (guild_id,)
    ) as cur:
        row = await cur.fetchone()
        return row[0] or 0


async def count_active_warnings(guild_id: int) -> int:
    async with _conn.execute("SELECT COUNT(*) FROM warnings WHERE guild_id=? AND active=1", (guild_id,)) as cur:
        row = await cur.fetchone()
        return row[0] or 0


async def backup_to(path: str) -> None:
    """Снимок базы в отдельный файл через VACUUM INTO — безопасно делать
    даже пока идёт запись (в отличие от простого копирования .db файла,
    которое в WAL-режиме может захватить неконсистентное состояние)."""
    await _conn.execute("VACUUM INTO ?", (path,))


# ---------------- панели тикетов/анкет (по каналу, не по серверу) ----------------
# panels (выше) — для войсов, там ОДНА панель на сервер. Тикетов/анкет на
# сервере может быть несколько каналов сразу, поэтому ключ — channel_id.
# Раньше это трекалось обычным словарём в памяти (ticket_messages/
# button_messages в dealer_bot.py) — после рестарта бота словарь обнулялся,
# бот не находил старую панель и не мог её удалить, она просто оставалась
# висеть в канале рядом с новой.

async def get_channel_panel(channel_id: int) -> int | None:
    async with _conn.execute(
        "SELECT message_id FROM channel_panels WHERE channel_id=?", (channel_id,)
    ) as cur:
        row = await cur.fetchone()
        return row[0] if row else None


async def save_channel_panel(channel_id: int, message_id: int) -> None:
    async with _write_lock:
        await _conn.execute(
            "INSERT INTO channel_panels (channel_id, message_id) VALUES (?, ?) "
            "ON CONFLICT(channel_id) DO UPDATE SET message_id=excluded.message_id",
            (channel_id, message_id),
        )
        await _conn.commit()

