"""
Живые ограничения по очкам предупреждений — вынесены в отдельный модуль
БЕЗ зависимостей от cogs/*, чтобы им могли пользоваться сразу несколько
когов (voice, anketa, suggestions, automod, moderation) без риска
циклического импорта между ними (например voice.py <-> moderation.py).

Не разовое действие (как punishments в moderation.py), а вопрос
"хватает ли СЕЙЧАС очков для флага" — считается заново при каждом вызове.
Как только очки падают (варн истёк/сняли), ограничение снимается само
в следующий же вызов, без отдельного кода отмены.
"""

import db
from dealer_bot import get_moderation_config


async def get_active_flags(guild_id: int, user_id: int) -> set[str]:
    """Набор активных ограничений участника по его текущим очкам."""
    config = get_moderation_config(guild_id)
    points = await db.get_total_points(guild_id, user_id)
    return {r["flag"] for r in config.get("restrictions", []) if points >= r["points"]}


async def has_flag(guild_id: int, user_id: int, flag: str) -> bool:
    flags = await get_active_flags(guild_id, user_id)
    return flag in flags


async def get_extra_anketa_cooldown(guild_id: int, user_id: int) -> int:
    """Самый большой подходящий порог доп. кулдауна анкеты по очкам (секунды, 0 — нет)."""
    config = get_moderation_config(guild_id)
    points = await db.get_total_points(guild_id, user_id)
    seconds = 0
    for tier in config.get("anketa_cooldown_tiers", []):
        if points >= tier["points"]:
            seconds = max(seconds, tier["seconds"])
    return seconds


async def get_soft_slowmode_seconds(guild_id: int, user_id: int) -> int:
    """Самый большой подходящий порог "мягкого" антиспам-интервала по очкам (0 — нет)."""
    config = get_moderation_config(guild_id)
    points = await db.get_total_points(guild_id, user_id)
    seconds = 0
    for tier in config.get("soft_slowmode_tiers", []):
        if points >= tier["points"]:
            seconds = max(seconds, tier["seconds"])
    return seconds
