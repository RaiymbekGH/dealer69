"""
Автоматический бэкап SQLite-базы — единственная точка отказа во всей
системе бота (в ней все варны, тикеты, предложения, очки, кулдауны).
Если файл повредится или диск подведёт — без бэкапа всё это пропадёт
без возможности восстановить.

Бэкап делается через db.backup_to() (VACUUM INTO) — безопасно даже
пока бот продолжает писать в базу, в отличие от простого копирования
файла (которое в WAL-режиме может захватить неконсистентный снимок).
"""

import asyncio
import logging
import os
import time

import disnake
from disnake.ext import commands, tasks

import db

log = logging.getLogger("backup_cog")

BACKUP_DIR = "backups"
KEEP_LAST = 14  # хранить последние N бэкапов (при ежедневном — это 2 недели)


class BackupCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.backup_loop.start()

    def cog_unload(self):
        self.backup_loop.cancel()

    async def _make_backup(self) -> str | None:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        timestamp = time.strftime("%Y-%m-%d_%H-%M-%S")
        path = os.path.join(BACKUP_DIR, f"backup_{timestamp}.db")
        try:
            await db.backup_to(path)
        except Exception as e:
            if "sql statements in progress" in str(e).lower():
                # VACUUM совпал по времени с чужой активной записью на том
                # же соединении — не редкость при живом боте. Пробуем ещё
                # раз через пару секунд, обычно этого достаточно.
                log.warning("Бэкап совпал с активной записью в БД, пробую ещё раз через 3с...")
                await asyncio.sleep(3)
                try:
                    await db.backup_to(path)
                except Exception as e2:
                    log.error("Не удалось создать бэкап БД (повторная попытка тоже не удалась): %s", e2)
                    return None
            else:
                log.error("Не удалось создать бэкап БД: %s", e)
                return None
        log.info("Бэкап БД создан: %s", path)
        self._prune_old_backups()
        return path

    def _prune_old_backups(self) -> None:
        files = sorted(f for f in os.listdir(BACKUP_DIR) if f.startswith("backup_") and f.endswith(".db"))
        excess = len(files) - KEEP_LAST
        for old_file in files[:excess]:
            try:
                os.remove(os.path.join(BACKUP_DIR, old_file))
            except OSError as e:
                log.warning("Не удалось удалить старый бэкап %s: %s", old_file, e)

    @tasks.loop(hours=24)
    async def backup_loop(self):
        await self._make_backup()

    @backup_loop.before_loop
    async def before_backup_loop(self):
        await self.bot.wait_until_ready()
        await db.init()
        # Цикл по умолчанию делает первый бэкап сразу же — а это ровно
        # момент, когда идёт шквал параллельных записей при старте бота
        # (панели анкет/тикетов/предложений). VACUUM INTO не может
        # выполняться, пока на том же соединении есть другие незавершённые
        # запросы — отсюда "cannot VACUUM - SQL statements in progress".
        # Даём минуту на то, чтобы всё утихло.
        await asyncio.sleep(60)

    @commands.slash_command(name="backup", description="Сделать резервную копию базы данных прямо сейчас (только администраторам)")
    async def backup_slash(self, inter: disnake.ApplicationCommandInteraction):
        if not inter.author.guild_permissions.administrator:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Требуются права администратора.", ephemeral=True)
            return
        await inter.response.defer(ephemeral=True)
        path = await self._make_backup()
        if path:
            await inter.edit_original_response(content=f"✅ Бэкап создан: `{path}`")
        else:
            await inter.edit_original_response(content="<:Other_problem:1528536802720350370> Не удалось создать бэкап — подробности в логе.")


def setup(bot: commands.Bot):
    bot.add_cog(BackupCog(bot))
