"""
Временные голосовые каналы — версия для крупного сервера.

Отличия от простой реализации:
- состояние (кто чем владеет, чёрные списки, id панели) хранится в SQLite
  и переживает рестарт бота (db.py);
- ключи владения — (guild_id, user_id), а не просто user_id, иначе бот
  на нескольких серверах будет путать владельцев;
- asyncio.Lock + кулдаун на создание комнаты — защита от гонки при
  быстром реконнекте и от спама created/deleted;
- проверка лимита Discord на 50 каналов в категории;
- автопередача владения, если хозяин вышел, а комната не опустела;
- чёрный список персональный (привязан к владельцу, а не к каналу) —
  переезжает вместе с ним в каждую новую комнату;
- канал-распределитель (см. distributor_channel в dealer_bot.py).
"""

import asyncio
import logging
import random
import time

import disnake
from disnake.ext import commands

import db
from dealer_bot import get_voice_config, VOICE_CONFIGS
from restrictions import has_flag as mod_has_flag

log = logging.getLogger("voice_cog")

# (guild_id, owner_id) -> channel_id — кэш поверх БД для быстрых обращений
owner_channel: dict[tuple[int, int], int] = {}
# channel_id -> (guild_id, owner_id) — обратный индекс
channel_owner: dict[int, tuple[int, int]] = {}

# защита от гонки/спама при создании комнаты
_creation_locks: dict[tuple[int, int], asyncio.Lock] = {}
_last_created: dict[tuple[int, int], float] = {}

# Discord разрешает переименовывать канал не чаще 2 раз за 10 минут — если
# превысить, channel.edit(name=...) может надолго "зависнуть", пока
# библиотека сама ждёт снятия лимита. Проверяем на своей стороне заранее,
# чтобы сразу вежливо отказать вместо зависания.
_rename_history: dict[int, list[float]] = {}
RENAME_WINDOW_SECONDS = 600
RENAME_MAX_PER_WINDOW = 2


def _can_rename(channel_id: int) -> tuple[bool, int]:
    now = time.monotonic()
    history = [t for t in _rename_history.get(channel_id, []) if now - t < RENAME_WINDOW_SECONDS]
    _rename_history[channel_id] = history
    if len(history) >= RENAME_MAX_PER_WINDOW:
        wait = int(RENAME_WINDOW_SECONDS - (now - history[0]))
        return False, wait
    return True, 0


def _record_rename(channel_id: int) -> None:
    _rename_history.setdefault(channel_id, []).append(time.monotonic())

# channel_id -> {member_id: последний момент захода} — чтобы предлагать
# владельцу список "кто заходил в комнату" вместо ввода ID вручную.
# Живёт только в памяти: комната временная, история заходов не нужна
# дольше её жизни, и чистится вместе с owner_channel при удалении канала.
channel_visitors: dict[int, dict[int, float]] = {}

MAX_CHANNELS_PER_CATEGORY = 50  # жёсткий лимит Discord


def _lock_for(key: tuple[int, int]) -> asyncio.Lock:
    if key not in _creation_locks:
        _creation_locks[key] = asyncio.Lock()
    return _creation_locks[key]


# ==================== ВСПОМОГАТЕЛЬНОЕ ====================

def build_panel_embed(config: dict) -> disnake.Embed:
    e = config.get("embed") or {}
    title = e.get("title") or config.get("panel_title") or "Панель управления войсом"
    description = e.get("description") or config.get("panel_description") or "Управление вашим голосовым каналом"

    # Автогайд: список "эмодзи — `что делает`" строится из тех же кнопок,
    # что реально на панели, — добавили/убрали кнопку, гайд обновился сам,
    # не нужно вручную править текст в двух местах.
    if e.get("auto_guide", True):
        lines = []
        for btn in config.get("buttons", []):
            if not btn.get("enabled", True):
                continue
            guide_text = btn.get("guide_text")
            emoji = btn.get("emoji") or btn.get("label", "")
            if guide_text:
                lines.append(f"{emoji} — `{guide_text}`")
        if lines:
            description = description.rstrip() + "\n\n" + "\n".join(lines)  + "\n\n > ⚠️ **Внимание!** перед заполнением заявки ознакомьтесь с правилами и политикой сервера"

    color = e.get("color", config.get("panel_color"))
    embed = disnake.Embed(title=title, description=description, color=color)
    if e.get("thumbnail"):
        embed.set_thumbnail(url=e["thumbnail"])
    if e.get("image"):
        embed.set_image(url=e["image"])
    if e.get("author_name"):
        embed.set_author(name=e["author_name"], icon_url=e.get("author_icon"))
    if e.get("footer_text"):
        embed.set_footer(text=e["footer_text"], icon_url=e.get("footer_icon"))
    if e.get("timestamp"):
        embed.timestamp = disnake.utils.utcnow()
    for field in e.get("fields", []):
        embed.add_field(
            name=field.get("name", "\u200b"),
            value=field.get("value", "\u200b"),
            inline=field.get("inline", True),
        )
    return embed


def _register_ownership(guild_id: int, owner_id: int, channel_id: int) -> None:
    owner_channel[(guild_id, owner_id)] = channel_id
    channel_owner[channel_id] = (guild_id, owner_id)


def _record_visitor(channel_id: int, member_id: int) -> None:
    """Запоминает, что этот участник заходил в комнату — источник списка
    "кто заходил" для выбора цели действия вместо ввода ID вручную."""
    channel_visitors.setdefault(channel_id, {})[member_id] = time.monotonic()


def _forget_ownership(guild_id: int, owner_id: int, channel_id: int) -> None:
    owner_channel.pop((guild_id, owner_id), None)
    channel_owner.pop(channel_id, None)
    channel_visitors.pop(channel_id, None)


async def get_owner_channel_followup(inter: disnake.Interaction, owner_id: int) -> disnake.VoiceChannel | None:
    """Отдаёт канал владельца или сама отвечает ошибкой через followup
    (используется везде, так как все действия сначала делают defer())."""
    key = (inter.guild.id, owner_id)
    channel_id = owner_channel.get(key)
    if channel_id is None:
        await inter.followup.send("<:Other_problem:1528536802720350370> У вас нет активной комнаты.", ephemeral=True)
        return None
    channel = inter.guild.get_channel(channel_id)
    if not channel:
        _forget_ownership(*key, channel_id)
        await db.remove_owner(*key)
        await inter.followup.send("<:Other_problem:1528536802720350370> Комната не найдена.", ephemeral=True)
        return None
    return channel


async def build_owner_overwrites(guild: disnake.Guild, member: disnake.Member) -> dict:
    overwrites = {
        guild.default_role: disnake.PermissionOverwrite(connect=False, view_channel=True),
        member: disnake.PermissionOverwrite(
            connect=True, view_channel=True, speak=True, stream=True,
            manage_channels=True, manage_permissions=True,
        ),
    }
    for banned_id in await db.get_blacklist(guild.id, member.id):
        banned_member = guild.get_member(banned_id)
        if banned_member:
            overwrites[banned_member] = disnake.PermissionOverwrite(connect=False)
    return overwrites


async def reassign_owner(guild: disnake.Guild, channel: disnake.VoiceChannel,
                          old_owner_id: int, new_owner: disnake.Member) -> None:
    await channel.set_permissions(new_owner, connect=True, view_channel=True, speak=True,
                                   stream=True, manage_channels=True, manage_permissions=True)
    old_owner = guild.get_member(old_owner_id)
    if old_owner:
        await channel.set_permissions(old_owner, connect=True, view_channel=True, speak=True, stream=True)
    _forget_ownership(guild.id, old_owner_id, channel.id)
    _register_ownership(guild.id, new_owner.id, channel.id)
    await db.remove_owner(guild.id, old_owner_id)
    await db.set_owner(guild.id, new_owner.id, channel.id)


# ==================== МОДАЛКИ: ТЕКСТОВЫЙ ВВОД ====================

class NameModal(disnake.ui.Modal):
    def __init__(self, user_id: int):
        self.user_id = user_id
        super().__init__(title="Изменение названия комнаты", components=[
            disnake.ui.TextInput(
                label="Новое название", placeholder="Введите новое название...",
                min_length=1, max_length=100, style=disnake.TextInputStyle.short,
                custom_id="name", required=True,
            )
        ])

    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.defer(ephemeral=True)
        channel = await get_owner_channel_followup(inter, self.user_id)
        if not channel:
            return
        can_rename, wait = _can_rename(channel.id)
        if not can_rename:
            await inter.followup.send(
                f"<:Other_problem:1528536802720350370> Discord позволяет переименовывать канал не чаще 2 раз за 10 минут. "
                f"Подождите ещё {wait // 60} мин {wait % 60} сек.", ephemeral=True,
            )
            return
        new_name = inter.text_values["name"].strip()
        try:
            await channel.edit(name=new_name)
            _record_rename(channel.id)
            await inter.followup.send(f"✅ Название изменено на **{new_name}**.", ephemeral=True, delete_after=5)
        except disnake.HTTPException as e:
            await inter.followup.send(f"<:Other_problem:1528536802720350370> Ошибка: {e}", ephemeral=True)


class LimitModal(disnake.ui.Modal):
    def __init__(self, user_id: int):
        self.user_id = user_id
        super().__init__(title="Установить лимит", components=[
            disnake.ui.TextInput(
                label="Лимит пользователей", placeholder="0 = безлимит",
                min_length=1, max_length=3, style=disnake.TextInputStyle.short,
                custom_id="limit", required=True,
            )
        ])

    async def callback(self, inter: disnake.ModalInteraction):
        await inter.response.defer(ephemeral=True)
        channel = await get_owner_channel_followup(inter, self.user_id)
        if not channel:
            return
        raw = inter.text_values["limit"].strip()
        if not raw.isdigit() or int(raw) > 99:
            await inter.followup.send("<:Other_problem:1528536802720350370> Введите число от 0 до 99.", ephemeral=True)
            return
        await channel.edit(user_limit=int(raw))
        await inter.followup.send(f"✅ Лимит: **{raw}**", ephemeral=True, delete_after=5)


# ==================== ПРЕСЕТЫ НАЗВАНИЙ ====================

class PresetSelect(disnake.ui.StringSelect):
    def __init__(self, owner_id: int, preset_names: list[str]):
        self.owner_id = owner_id
        options = [disnake.SelectOption(label=name[:100], value=name[:100]) for name in preset_names[:25]]
        super().__init__(placeholder="Выберите название...", options=options)

    async def callback(self, inter: disnake.MessageInteraction):
        await inter.response.defer(ephemeral=True)
        channel = await get_owner_channel_followup(inter, self.owner_id)
        if not channel:
            return
        can_rename, wait = _can_rename(channel.id)
        if not can_rename:
            await inter.followup.send(
                f"<:Other_problem:1528536802720350370> Discord позволяет переименовывать канал не чаще 2 раз за 10 минут. "
                f"Подождите ещё {wait // 60} мин {wait % 60} сек.", ephemeral=True,
            )
            return
        chosen = self.values[0]
        try:
            await channel.edit(name=chosen)
            _record_rename(channel.id)
            await inter.followup.send(f"✅ Название изменено на **{chosen}**.", ephemeral=True, delete_after=5)
        except disnake.HTTPException as e:
            await inter.followup.send(f"<:Other_problem:1528536802720350370> Ошибка: {e}", ephemeral=True)


class PresetView(disnake.ui.View):
    def __init__(self, owner_id: int, preset_names: list[str]):
        super().__init__(timeout=60)
        if preset_names:
            self.add_item(PresetSelect(owner_id, preset_names))
        self.add_item(CustomNameButton(owner_id))


class CustomNameButton(disnake.ui.Button):
    def __init__(self, owner_id: int):
        super().__init__(label="Своё название", emoji="✏️", style=disnake.ButtonStyle.secondary)
        self.owner_id = owner_id

    async def callback(self, inter: disnake.MessageInteraction):
        await inter.response.send_modal(NameModal(self.owner_id))


# ==================== ДЕЙСТВИЯ ПО ID ПОЛЬЗОВАТЕЛЯ ====================

async def handle_add(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    await channel.set_permissions(target, connect=True)
    await db.unban(inter.guild.id, inter.author.id, target.id)  # прощаем, если был в ЧС
    await inter.followup.send(f"✅ {target.mention} добавлен в доступ.", ephemeral=True, delete_after=5)


async def handle_remove(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    await channel.set_permissions(target, connect=False)
    if target in channel.members:
        try:
            await target.move_to(None)
        except disnake.HTTPException:
            pass
    # персистентный бан — переедет вместе с владельцем в его следующую комнату
    await db.ban(inter.guild.id, inter.author.id, target.id)
    await inter.followup.send(
        f"✅ Доступ {target.mention} забран (и он в ЧС ваших будущих комнат).",
        ephemeral=True, delete_after=6,
    )


async def handle_kick(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    if target not in channel.members:
        await inter.followup.send("<:Other_problem:1528536802720350370> Пользователь не в комнате.", ephemeral=True)
        return
    await target.move_to(None)
    await inter.followup.send(f"✅ {target.mention} выгнан (без внесения в ЧС).", ephemeral=True, delete_after=5)


async def handle_toggle_access(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    """Одна кнопка вместо пары ДОБАВИТЬ/ЗАБРАТЬ: сама определяет, что сейчас нужно сделать."""
    currently_allowed = channel.overwrites_for(target).connect is True
    if currently_allowed:
        await handle_remove(inter, channel, target)
    else:
        await handle_add(inter, channel, target)


async def handle_toggle_speak(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    currently_muted = channel.overwrites_for(target).speak is False
    await channel.set_permissions(target, speak=True if currently_muted else False)
    status = "теперь может говорить" if currently_muted else "лишён права говорить"
    await inter.followup.send(f"🎙️ {target.mention} {status}.", ephemeral=True, delete_after=5)


async def handle_reset_user(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    await channel.set_permissions(target, overwrite=None)
    await inter.followup.send(f"🗑️ Права {target.mention} сброшены до стандартных.", ephemeral=True, delete_after=5)


async def handle_transfer(inter: disnake.Interaction, channel: disnake.VoiceChannel, target: disnake.Member):
    if target not in channel.members:
        await inter.followup.send("<:Other_problem:1528536802720350370> Новый владелец должен быть в комнате.", ephemeral=True)
        return
    await reassign_owner(inter.guild, channel, inter.author.id, target)
    await inter.followup.send(f"👑 Владельцем комнаты теперь {target.mention}.", ephemeral=True, delete_after=5)


TARGET_ACTIONS = {
    "add": ("Добавить в доступ", handle_add),
    "remove": ("Забрать доступ (+ЧС)", handle_remove),
    "toggle_access": ("Доступ пользователю", handle_toggle_access),
    "toggle_speak": ("Право говорить", handle_toggle_speak),
    "reset_user": ("Сбросить права пользователю", handle_reset_user),
    "kick": ("Выгнать", handle_kick),
    "transfer": ("Передать владение", handle_transfer),
}


class TargetPickerView(disnake.ui.View):
    """Заменяет ручной ввод ID: сначала предлагает тех, кто недавно заходил
    в комнату (быстрый выбор), плюс нативный поиск по всем участникам
    сервера (disnake.ui.UserSelect) — для тех, кого в комнате ещё не было."""

    def __init__(self, action: str, owner_id: int, channel_id: int, guild: disnake.Guild):
        super().__init__(timeout=120)
        self.action = action
        self.owner_id = owner_id

        visitors = channel_visitors.get(channel_id, {})
        recent_ids = sorted(visitors, key=visitors.get, reverse=True)  # свежие заходы первыми
        options = []
        for uid in recent_ids:
            if uid == owner_id:
                continue
            member = guild.get_member(uid)
            if member:
                options.append(disnake.SelectOption(label=member.display_name[:100], value=str(uid)))
            if len(options) >= 25:
                break

        if options:
            recent_select = disnake.ui.StringSelect(
                placeholder="Кто недавно заходил в вашу комнату...",
                options=options,
            )

            async def recent_callback(inter: disnake.MessageInteraction):
                target = inter.guild.get_member(int(recent_select.values[0]))
                await self._apply(inter, target)

            recent_select.callback = recent_callback
            self.add_item(recent_select)

        user_select = disnake.ui.UserSelect(placeholder="Или найдите любого участника сервера...")

        async def user_callback(inter: disnake.MessageInteraction):
            target = user_select.values[0] if user_select.values else None
            await self._apply(inter, target)

        user_select.callback = user_callback
        self.add_item(user_select)

    async def _apply(self, inter: disnake.MessageInteraction, target):
        await inter.response.defer(ephemeral=True)
        channel = await get_owner_channel_followup(inter, self.owner_id)
        if not channel:
            return
        if not isinstance(target, disnake.Member):
            await inter.followup.send("<:Other_problem:1528536802720350370> Пользователь не найден на сервере.", ephemeral=True)
            return
        if target.id == self.owner_id:
            await inter.followup.send("<:Other_problem:1528536802720350370> Нельзя применить это действие к самому себе.", ephemeral=True)
            return
        _, handler = TARGET_ACTIONS[self.action]
        await handler(inter, channel, target)


# ==================== КНОПКИ ПАНЕЛИ ====================

class VoiceActionButton(disnake.ui.Button):
    def __init__(self, config: dict, action: str, label: str | None = None,
                 emoji: str | None = None, style: str = "secondary", row: int | None = None):
        super().__init__(
            label=label or None,   # None — кнопка будет чисто иконкой, без подписи
            emoji=emoji,
            style=getattr(disnake.ButtonStyle, style, disnake.ButtonStyle.secondary),
            custom_id=f"v_{action}",
            row=row,
        )
        self.config = config
        self.action = action

    async def callback(self, inter: disnake.MessageInteraction):
        action = self.action

        if action == "name":
            names = self.config.get("preset_names") or []
            if names:
                await inter.response.send_message(
                    "Выберите название комнаты:", view=PresetView(inter.author.id, names), ephemeral=True,
                )
            else:
                await inter.response.send_modal(NameModal(inter.author.id))
            return
        if action == "limit":
            await inter.response.send_modal(LimitModal(inter.author.id))
            return
        if action in TARGET_ACTIONS:
            key = (inter.guild.id, inter.author.id)
            channel_id = owner_channel.get(key)
            if channel_id is None:
                await inter.response.send_message("<:Other_problem:1528536802720350370> У вас нет активной комнаты.", ephemeral=True)
                return
            await inter.response.send_message(
                "Выберите участника:",
                view=TargetPickerView(action, inter.author.id, channel_id, inter.guild),
                ephemeral=True,
            )
            return

        await inter.response.defer(ephemeral=True)
        channel = await get_owner_channel_followup(inter, inter.author.id)
        if not channel:
            return

        if action == "access":
            await self._toggle_access(inter, channel)
        elif action == "hide":
            await self._toggle_visibility(inter, channel)
        elif action == "status":
            await self._send_status(inter, channel)
        elif action == "delete":
            await self._delete_channel(inter, channel)

    async def _toggle_access(self, inter, channel: disnake.VoiceChannel):
        everyone = inter.guild.default_role
        currently_open = channel.overwrites_for(everyone).connect is not False
        await channel.set_permissions(everyone, connect=False if currently_open else True)
        status = "закрыт" if currently_open else "открыт"
        await inter.followup.send(f"🔓 Доступ {status}.", ephemeral=True, delete_after=5)

    async def _toggle_visibility(self, inter, channel: disnake.VoiceChannel):
        everyone = inter.guild.default_role
        currently_visible = channel.overwrites_for(everyone).view_channel is not False
        await channel.set_permissions(everyone, view_channel=False if currently_visible else True)
        status = "скрыта" if currently_visible else "показана"
        await inter.followup.send(f"👁️ Комната {status}.", ephemeral=True, delete_after=5)

    async def _send_status(self, inter, channel: disnake.VoiceChannel):
        embed = disnake.Embed(title="📊 Статус комнаты", color=disnake.Color.blue())
        embed.add_field(name="Название", value=channel.name, inline=False)
        embed.add_field(name="Участников", value=str(len(channel.members)), inline=True)
        embed.add_field(name="Лимит", value=str(channel.user_limit) if channel.user_limit else "∞", inline=True)
        embed.add_field(name="Битрейт", value=f"{channel.bitrate // 1000} кбит/с", inline=True)
        embed.add_field(name="Регион", value=channel.rtc_region or "Авто", inline=True)
        await inter.followup.send(embed=embed, ephemeral=True, delete_after=30)

    async def _delete_channel(self, inter, channel: disnake.VoiceChannel):
        if len(channel.members) > 1:
            await inter.followup.send("<:Other_problem:1528536802720350370> В комнате есть другие участники!", ephemeral=True)
            return
        try:
            await channel.delete()
            _forget_ownership(inter.guild.id, inter.author.id, channel.id)
            await db.remove_owner(inter.guild.id, inter.author.id)
            await inter.followup.send("✅ Комната удалена!", ephemeral=True, delete_after=3)
        except disnake.HTTPException:
            await inter.followup.send("<:Other_problem:1528536802720350370> Ошибка при удалении.", ephemeral=True)


class VoicePanelView(disnake.ui.View):
    def __init__(self, config: dict):
        super().__init__(timeout=None)
        for btn in config.get("buttons", []):
            if btn.get("enabled", True):
                self.add_item(VoiceActionButton(
                    config, btn["action"],
                    label=btn.get("label"),
                    emoji=btn.get("emoji"),
                    style=btn.get("style", "secondary"),
                    row=btn.get("row"),
                ))


async def send_or_update_panel(guild: disnake.Guild):
    config = get_voice_config(guild.id)
    if not config["setting_channel"]:
        return
    setting_channel = guild.get_channel(config["setting_channel"])
    if not setting_channel:
        return

    old_message_id = await db.get_panel(guild.id)
    if old_message_id:
        try:
            old_msg = await setting_channel.fetch_message(old_message_id)
            await old_msg.delete()
        except disnake.HTTPException:
            pass

    embed = build_panel_embed(config)
    view = VoicePanelView(config)
    msg = await setting_channel.send(embed=embed, view=view)
    await db.save_panel(guild.id, msg.id)


# ==================== COG ====================

class VoiceCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize())

    async def initialize(self):
        await self.bot.wait_until_ready()
        await db.init()
        for guild_id in VOICE_CONFIGS:
            guild = self.bot.get_guild(guild_id)
            if not guild:
                continue
            await self._restore_state(guild)
            await send_or_update_panel(guild)

    async def _restore_state(self, guild: disnake.Guild):
        """Восстанавливает владение комнатами из БД после рестарта бота."""
        for owner_id, channel_id in await db.load_all_owners(guild.id):
            channel = guild.get_channel(channel_id)
            if channel is None:
                # комнату удалили, пока бот был выключен — чистим хвост в БД
                await db.remove_owner(guild.id, owner_id)
                continue
            _register_ownership(guild.id, owner_id, channel_id)

    @commands.Cog.listener()
    async def on_voice_state_update(self, member: disnake.Member, before: disnake.VoiceState, after: disnake.VoiceState):
        if member.bot:
            return
        guild = member.guild
        config = get_voice_config(guild.id)

        creator_entry = None
        if after.channel:
            creator_entry = next(
                (c for c in config.get("creators", []) if c.get("channel_id") == after.channel.id), None,
            )

        if creator_entry:
            await self._handle_join_creator(member, guild, config, creator_entry)
        elif after.channel and config.get("distributor_channel") and after.channel.id == config["distributor_channel"]:
            await self._handle_join_distributor(member, guild, config)

        # Автомут по очкам предупреждений — работает в ЛЮБОМ голосовом канале
        # сервера, не только временных. Проверяем только при реальном заходе
        # в канал (не на каждое мелкое изменение состояния типа своего мута).
        if after.channel and (before.channel is None or before.channel.id != after.channel.id) and not after.mute:
            if await mod_has_flag(guild.id, member.id, "no_voice_speak"):
                try:
                    await member.edit(mute=True, reason="Ограничение по очкам предупреждений")
                except disnake.HTTPException:
                    pass

        # Запоминаем захода в ЛЮБУЮ временную комнату (свою или чужую) —
        # владелец сможет выбрать этого человека из списка вместо ввода ID.
        if after.channel and after.channel.id in channel_owner:
            _record_visitor(after.channel.id, member.id)

        if before.channel and before.channel.id in channel_owner:
            await self._handle_leave(member, before.channel, guild)

    @staticmethod
    def _pick_category(guild: disnake.Guild, config: dict, creator_entry: dict | None) -> disnake.CategoryChannel | None:
        """Ищет первую категорию из пула, где ещё есть место (лимит Discord — 50 каналов)."""
        pool = (creator_entry or {}).get("categories") or config.get("categories") or []
        for cat_id in pool:
            category = guild.get_channel(cat_id)
            if category and len(category.channels) < MAX_CHANNELS_PER_CATEGORY:
                return category
        return None

    @staticmethod
    def _all_categories(guild: disnake.Guild, config: dict) -> list[disnake.CategoryChannel]:
        """Все категории пула (общего + всех входов-по-интересам), для распределителя."""
        ids = set(config.get("categories", []))
        for c in config.get("creators", []):
            ids.update(c.get("categories") or [])
        result = []
        for cat_id in ids:
            category = guild.get_channel(cat_id)
            if category:
                result.append(category)
        return result

    async def _handle_join_creator(self, member: disnake.Member, guild: disnake.Guild,
                                    config: dict, creator_entry: dict):
        key = (guild.id, member.id)

        async with _lock_for(key):
            existing_id = owner_channel.get(key)
            if existing_id:
                existing = guild.get_channel(existing_id)
                if existing:
                    await member.move_to(existing)
                    return
                _forget_ownership(*key, existing_id)
                await db.remove_owner(*key)

            # Ограничение по очкам — но только на СОЗДАНИЕ новой комнаты,
            # к уже существующей своей комнате (выше) доступ не режем.
            if await mod_has_flag(guild.id, member.id, "no_voice_create"):
                return

            cooldown = config.get("creation_cooldown_seconds", 5)
            last = _last_created.get(key, 0)
            if time.monotonic() - last < cooldown:
                return  # слишком часто — молча игнорируем, чтобы не спамить API

            category = self._pick_category(guild, config, creator_entry)
            if not category:
                log.warning(
                    "Все категории из пула заполнены (лимит Discord 50 каналов), "
                    "комната для %s (интерес: %s) не создана — добавьте ещё категорию в конфиг",
                    member.id, creator_entry.get("label", "?"),
                )
                return

            try:
                overwrites = await build_owner_overwrites(guild, member)
                template = creator_entry.get("name_template") or config.get("channel_name_template", "Комната {user}")
                name = template.format(user=member.display_name)
                new_channel = await guild.create_voice_channel(
                    name=name, category=category, overwrites=overwrites, user_limit=0,
                )
                label = creator_entry.get("label")
                if label:
                    try:
                        await new_channel.edit(topic=label)
                    except disnake.HTTPException:
                        pass  # у голосовых топиков есть нюансы по правам/версии — не критично
                _register_ownership(guild.id, member.id, new_channel.id)
                await db.set_owner(guild.id, member.id, new_channel.id)
                _last_created[key] = time.monotonic()
                await member.move_to(new_channel)
                # Кастомное событие: любой ког может подписаться и среагировать
                # на создание временной комнаты, не будучи связан с voice.py
                # напрямую (например cogs/ads.py постит туда рекламу).
                self.bot.dispatch("temp_voice_created", new_channel, guild, member)
            except disnake.HTTPException as e:
                log.error("Ошибка создания голосового канала для %s: %s", member.id, e)

    async def _handle_join_distributor(self, member: disnake.Member, guild: disnake.Guild, config: dict):
        # Ограничение по очкам: нельзя попасть в чужую комнату через
        # "распределитель" — только по личному приглашению владельца
        # (это по-прежнему работает, доступ к своим комнатам не режется).
        if await mod_has_flag(guild.id, member.id, "voice_join_invite_only"):
            return

        categories = self._all_categories(guild, config)
        if not categories:
            return

        skip_ids = {c.get("channel_id") for c in config.get("creators", [])}
        skip_ids.add(config.get("distributor_channel"))
        skip_ids.add(config.get("setting_channel"))

        candidates = []
        for category in categories:
            for ch in category.voice_channels:
                if ch.id in skip_ids or len(ch.members) == 0:
                    continue
                if config.get("distributor_ignore_full", True) and ch.user_limit and len(ch.members) >= ch.user_limit:
                    continue
                if config.get("distributor_ignore_locked", True) and ch.overwrites_for(guild.default_role).connect is False:
                    continue
                candidates.append(ch)

        if not candidates:
            return

        strategy = config.get("distributor_strategy", "least_members")
        target = random.choice(candidates) if strategy == "random" else min(candidates, key=lambda c: len(c.members))

        try:
            await member.move_to(target)
        except disnake.HTTPException:
            pass

    async def _handle_leave(self, member: disnake.Member, channel: disnake.VoiceChannel, guild: disnake.Guild):
        owner_key = channel_owner.get(channel.id)
        if not owner_key:
            return
        g_id, owner_id = owner_key

        if len(channel.members) == 0:
            try:
                await channel.delete()
            except disnake.HTTPException:
                pass
            _forget_ownership(g_id, owner_id, channel.id)
            await db.remove_owner(g_id, owner_id)
            return

        if member.id == owner_id:
            new_owner = next((m for m in channel.members if not m.bot), None)
            if new_owner:
                await reassign_owner(guild, channel, owner_id, new_owner)

    @commands.slash_command(name="voice_unban", description="Снять пользователя из личного ЧС владельца комнаты")
    async def admin_unban(
        self, inter: disnake.ApplicationCommandInteraction,
        owner: disnake.Member = commands.Param(description="Владелец комнаты, из чьего ЧС снимаем"),
        target: disnake.Member = commands.Param(description="Кого убрать из ЧС"),
    ):
        if not inter.author.guild_permissions.administrator:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Требуются права администратора.", ephemeral=True)
            return
        await db.unban(inter.guild.id, owner.id, target.id)
        await inter.response.send_message(f"✅ {target.mention} убран из ЧС {owner.mention}.")

    def cog_unload(self):
        # соединение с БД общее на процесс бота — не закрываем его здесь,
        # чтобы не сломать другие коги при hot-reload именно этого кога.
        pass


def setup(bot: commands.Bot):
    bot.add_cog(VoiceCog(bot))
