"""
Система предложений по улучшению сервера.

Как это работает:
- В канале висит панель с кнопкой "Предложить идею" (как у анкет/тикетов).
- Нажатие открывает модалку с текстом предложения.
- Предложение публикуется отдельным сообщением с кнопками голосования
  👍/👎 (один человек — один голос, можно передумать) и кнопками для
  модерации ✅ Одобрить / <:Other_problem:1528536802720350370> Отклонить / 🚀 Реализовано (видны всем, но
  сработают только у ролей из "review_roles" или у администраторов).
- Голоса и статус хранятся в SQLite (db.py) — переживают рестарт бота,
  как и у тикетов: кнопки на уже опубликованных предложениях снова
  регистрируются при старте, а не превращаются в мёртвые декорации.
"""

import datetime
import logging
import time

import disnake
from disnake.ext import commands

import db
from dealer_bot import get_suggestion_config
from restrictions import has_flag as mod_has_flag

log = logging.getLogger("suggestions_cog")

STATUS_META = {
    "pending":     {"label": "🕒 На рассмотрении", "color": None},
    "approved":    {"label": "✅ Одобрено",         "color": 0x00C853},
    "rejected":    {"label": "<:Other_problem:1528536802720350370> Отклонено",        "color": 0xD82318},
    "implemented": {"label": "🚀 Реализовано",      "color": 0x00B8D4},
}

def _is_reviewer(member: disnake.Member, config: dict) -> bool:
    if member.guild_permissions.administrator:
        return True
    review_roles = config.get("review_roles", [])
    return any(role.id in review_roles for role in member.roles)


def _can_vote(member: disnake.Member, config: dict) -> bool:
    # Сначала запрещающий список — этим ролям нельзя голосовать НИКОГДА,
    # даже если они как-то попадают в разрешающий список ниже.
    blocked = config.get("blocked_vote_roles", [])
    if any(role.id in blocked for role in member.roles):
        return False

    vote_roles = config.get("vote_roles", [])
    if not vote_roles:
        return True  # пусто = голосовать может любой участник сервера (кроме заблокированных выше)
    return any(role.id in vote_roles for role in member.roles)


def _can_create(member: disnake.Member, config: dict) -> bool:
    blocked = config.get("blocked_create_roles", [])
    return not any(role.id in blocked for role in member.roles)


def build_suggestion_embed(config: dict, author: disnake.Member | None, text: str,
                            status: str, reason: str | None, up: int, down: int,
                            created_at: float | None = None) -> disnake.Embed:
    meta = STATUS_META.get(status, STATUS_META["pending"])
    embed = disnake.Embed(description=text, color=meta["color"])
    if config.get("anonymous"):
        embed.set_author(name="Анонимное предложение")
    elif author:
        embed.set_author(name=author.display_name, icon_url=author.display_avatar.url)
    up_emoji = config.get("upvote_emoji")
    down_emoji = config.get("downvote_emoji")
    if config.get("voting_enabled", True):
        footer = f"{meta['label']} \n За: {up} \n Против: {down}"
    else:
        footer = meta["label"]  # голосование выключено конфигом — счётчики не показываем
    if reason:
        footer += f" • Причина: {reason}"
    embed.set_footer(text=footer)
    # Время создания (как у анкеты) — берём СОХРАНЁННОЕ время создания, а не
    # "сейчас", иначе при каждом одобрении/голосовании штамп бы съезжал на
    # момент последнего изменения вместо момента подачи предложения.
    if created_at:
        embed.timestamp = datetime.datetime.fromtimestamp(created_at, tz=datetime.timezone.utc)
    return embed


class SuggestionModal(disnake.ui.Modal):
    def __init__(self, channel_id: int, config: dict):
        self.channel_id = channel_id
        self.config = config
        super().__init__(title=config.get("modal_title", "Новое предложение"), components=[
            disnake.ui.TextInput(
                label=config.get("field_label", "Ваше предложение"),
                placeholder=config.get("field_placeholder", "Опишите идею подробно..."),
                min_length=config.get("min_length", 10),
                max_length=config.get("max_length", 1000),
                style=disnake.TextInputStyle.paragraph,
                custom_id="text",
                required=True,
            )
        ])

    async def callback(self, inter: disnake.ModalInteraction):
        # Дефер СРАЗУ: дальше идёт цепочка из нескольких запросов к Discord
        # (вебхук, БД, переотправка панели) — они легко не укладываются в
        # 3 секунды, которые Discord даёт на первый ответ на интеракцию.
        # Без defer это падает с "Interaction took more than 3 seconds".
        await inter.response.defer(ephemeral=True)

        if await mod_has_flag(inter.guild.id, inter.author.id, "no_suggestion_create"):
            await inter.followup.send(
                "<:Other_problem:1528536802720350370> Доступ к созданию предложений временно ограничен из-за предупреждений.", ephemeral=True,
            )
            return

        config = self.config
        cooldown = config.get("cooldown_seconds")
        now = time.time()
        last = await db.get_last_suggestion_time(inter.guild.id, inter.author.id)
        if last is not None and now - last < cooldown:
            wait_left = int(cooldown - (now - last))
            hours, minutes = divmod(wait_left // 60, 60)
            await inter.followup.send(
                f"<a:Loading:1528999376549314691> Следующее предложение можно отправить через {hours} ч {minutes} мин.", ephemeral=True,
            )
            return

        text = inter.text_values["text"].strip()
        suggestion_id = await db.create_suggestion(inter.guild.id, self.channel_id, inter.author.id, text)
        await db.set_last_suggestion_time(inter.guild.id, inter.author.id, now)

        target_channel = inter.guild.get_channel(config.get("feed_channel_id") or self.channel_id)
        if not target_channel:
            await inter.followup.send("<:Other_problem:1528536802720350370> Канал для публикации предложений не найден.", ephemeral=True)
            return

        embed = build_suggestion_embed(config, inter.author, text, "pending", None, 0, 0, created_at=now)
        view = SuggestionView(suggestion_id, config)

        msg = await target_channel.send(embed=embed, view=view)

        await db.set_suggestion_message(suggestion_id, msg.id)
        inter.bot.add_view(view)

        # Панель "Предложить идею" должна оставаться самым нижним (последним)
        # сообщением канала, чтобы её было видно без прокрутки — переотправляем
        # её после каждого нового предложения.
        suggestions_cog = inter.bot.get_cog("SuggestionsCog")
        if suggestions_cog:
            try:
                await clean_old_suggestion_panels(target_channel)
                await suggestions_cog.send_suggestion_panel(target_channel)
            except disnake.HTTPException as e:
                log.warning("Не удалось переотправить панель предложений: %s", e)

        await inter.followup.send(
            f"✅ Предложение опубликовано в {target_channel.mention}!", ephemeral=True, delete_after=5,
        )


class SuggestionRejectReasonModal(disnake.ui.Modal):
    def __init__(self, suggestion_id: int, channel_id: int, message_id: int, config: dict):
        self.suggestion_id = suggestion_id
        self.channel_id = channel_id
        self.message_id = message_id
        self.config = config
        super().__init__(title="Причина отклонения", components=[
            disnake.ui.TextInput(
                label="Причина (необязательно)", placeholder="Почему предложение отклонено...",
                min_length=0, max_length=300, required=False,
                style=disnake.TextInputStyle.paragraph, custom_id="reason",
            )
        ])

    async def callback(self, inter: disnake.ModalInteraction):
        reason = inter.text_values["reason"].strip() or None
        await _apply_status(inter, self.suggestion_id, self.channel_id, self.message_id, self.config,
                             "rejected", reason)


async def _apply_status(inter: disnake.Interaction, suggestion_id: int, channel_id: int, message_id: int,
                         config: dict, status: str, reason: str | None = None):
    await db.set_suggestion_status(suggestion_id, status, reason)
    row = await db.get_suggestion(suggestion_id)
    if not row:
        return
    _, guild_id, _, _, author_id, text, _, _, created_at = row
    up, down = await db.get_vote_counts(suggestion_id)
    author = inter.guild.get_member(author_id)
    embed = build_suggestion_embed(config, author, text, status, reason, up, down, created_at=created_at)

    channel = inter.guild.get_channel(channel_id)
    try:
        if status in ("rejected", "implemented"):
            # финальное решение — кнопки убираем совсем (не просто блокируем),
            # чтобы под решённым предложением visually ничего не оставалось
            view = None
        else:
            view = SuggestionView(suggestion_id, config)

        message = await channel.fetch_message(message_id)
        await message.edit(embed=embed, view=view)
    except disnake.HTTPException as e:
        log.warning("Не удалось обновить сообщение предложения %s: %s", suggestion_id, e)

    if inter.response.is_done():
        await inter.followup.send(f"✅ Статус обновлён: {STATUS_META[status]['label']}", ephemeral=True, delete_after=5)
    else:
        await inter.response.send_message(f"✅ Статус обновлён: {STATUS_META[status]['label']}", ephemeral=True, delete_after=5)


class SuggestionView(disnake.ui.View):
    def __init__(self, suggestion_id: int, config: dict):
        super().__init__(timeout=None)
        self.suggestion_id = suggestion_id
        self.config = config

        if config.get("voting_enabled", True):
            up_emoji = config.get("upvote_emoji")
            down_emoji = config.get("downvote_emoji")
            self.add_item(self._button(up_emoji, disnake.ButtonStyle.secondary, "up", 0))
            self.add_item(self._button(down_emoji, disnake.ButtonStyle.secondary, "down", 0))

        self.add_item(self._button("✅", disnake.ButtonStyle.success, "approve", 1))
        self.add_item(self._button("<:Other_problem:1528536802720350370>", disnake.ButtonStyle.danger, "reject", 1))
        self.add_item(self._button("🚀", disnake.ButtonStyle.primary, "implement", 1))

    def _button(self, emoji: str, style: disnake.ButtonStyle, kind: str, row: int) -> disnake.ui.Button:
        btn = disnake.ui.Button(emoji=emoji, style=style, custom_id=f"sugg_{kind}_{self.suggestion_id}", row=row)
        btn.callback = self._make_callback(kind)
        return btn

    def _make_callback(self, kind: str):
        async def callback(inter: disnake.MessageInteraction):
            if kind in ("up", "down"):
                await self._handle_vote(inter, kind)
            else:
                await self._handle_review(inter, kind)
        return callback

    async def _handle_vote(self, inter: disnake.MessageInteraction, kind: str):
        if not _can_vote(inter.author, self.config):
            await inter.response.send_message("<:Other_problem:1528536802720350370> У вас нет прав голосовать за предложения.", ephemeral=True)
            return
        if await mod_has_flag(inter.guild.id, inter.author.id, "no_suggestion_vote"):
            await inter.response.send_message(
                "<:Other_problem:1528536802720350370> Доступ к голосованию временно ограничен из-за предупреждений.", ephemeral=True,
            )
            return

        row = await db.get_suggestion(self.suggestion_id)
        if not row:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Предложение не найдено.", ephemeral=True)
            return
        _, guild_id, channel_id, message_id, author_id, text, status, reason, created_at = row
        if status != "pending":
            await inter.response.send_message("<:Other_problem:1528536802720350370> Голосование закрыто — решение уже принято.", ephemeral=True)
            return

        value = 1 if kind == "up" else -1
        up, down = await db.cast_vote(self.suggestion_id, inter.author.id, value)
        author = inter.guild.get_member(author_id)
        embed = build_suggestion_embed(self.config, author, text, status, reason, up, down, created_at=created_at)
        await inter.response.edit_message(embed=embed)

    async def _handle_review(self, inter: disnake.MessageInteraction, kind: str):
        if not _is_reviewer(inter.author, self.config):
            await inter.response.send_message("<:Other_problem:1528536802720350370> У вас нет прав рассматривать предложения.", ephemeral=True)
            return

        row = await db.get_suggestion(self.suggestion_id)
        if row and row[6] in ("rejected", "implemented"):
            await inter.response.send_message("<:Other_problem:1528536802720350370> Решение по этому предложению уже финальное.", ephemeral=True)
            return

        status_map = {"approve": "approved", "reject": "rejected", "implement": "implemented"}
        status = status_map[kind]

        if status == "rejected" and self.config.get("require_reason_on_reject", True):
            await inter.response.send_modal(
                SuggestionRejectReasonModal(self.suggestion_id, inter.channel.id, inter.message.id, self.config)
            )
            return

        await inter.response.defer(ephemeral=True)
        await _apply_status(inter, self.suggestion_id, inter.channel.id, inter.message.id, self.config, status)


# ==================== ПАНЕЛЬ ВХОДА ====================

class SuggestionButton(disnake.ui.Button):
    def __init__(self, channel_id: int, config: dict):
        style = getattr(disnake.ButtonStyle, config.get("button_style", "primary"), disnake.ButtonStyle.primary)
        super().__init__(label=config.get("button_label"), style=style,
                          custom_id=f"suggestion_panel_{channel_id}")
        self.channel_id = channel_id
        self.config = config

    async def callback(self, inter: disnake.MessageInteraction):
        if not _can_create(inter.author, self.config):
            await inter.response.send_message(
                "<:Other_problem:1528536802720350370> У вас нет прав создавать предложения.", ephemeral=True,
            )
            return
        await inter.response.send_modal(SuggestionModal(self.channel_id, self.config))


class SuggestionPanelView(disnake.ui.View):
    def __init__(self, channel_id: int, config: dict):
        super().__init__(timeout=None)
        self.add_item(SuggestionButton(channel_id, config))


async def clean_old_suggestion_panels(channel: disnake.TextChannel) -> int:
    """Удаляет только старое сообщение-панель ("Предложить идею"), не трогая
    уже опубликованные предложения — канал нельзя чистить целиком, в отличие
    от тикетов, потому что тут же лежит история всех предложений."""
    prefix = "suggestion_panel_"
    deleted = 0
    try:
        async for message in channel.history(limit=100):
            for row in message.components:
                for component in row.children:
                    if getattr(component, "custom_id", None) and component.custom_id.startswith(prefix):
                        await message.delete()
                        deleted += 1
                        break
    except disnake.HTTPException as e:
        log.warning("Ошибка при очистке старой панели предложений в канале %s: %s", channel.id, e)
    return deleted


# ==================== КОГ ====================

class SuggestionsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize())

    async def initialize(self):
        await self.bot.wait_until_ready()
        await db.init()
        restored = 0
        for suggestion_id, guild_id, channel_id, message_id in await db.load_open_suggestions():
            guild = self.bot.get_guild(guild_id)
            channel = guild.get_channel(channel_id) if guild else None
            if not channel:
                continue
            config = get_suggestion_config(channel_id)
            view = SuggestionView(suggestion_id, config)
            self.bot.add_view(view, message_id=message_id)
            restored += 1
        if restored:
            log.info("Восстановлено %d предложений после рестарта.", restored)

    async def send_suggestion_panel(self, channel: disnake.TextChannel):
        config = get_suggestion_config(channel.id)
        embed = disnake.Embed(
            title=config.get("panel_title"),
            description=config.get("panel_description") + "\n\n > ⚠️ **Внимание!** перед заполнением заявки ознакомьтесь с правилами и политикой сервера",
            color=config.get("embed_color"),
        )
        view = SuggestionPanelView(channel.id, config)
        await channel.send(embed=embed, view=view)

    async def clean_old_suggestion_panels(self, channel: disnake.TextChannel) -> int:
        return await clean_old_suggestion_panels(channel)


def setup(bot: commands.Bot):
    bot.add_cog(SuggestionsCog(bot))
