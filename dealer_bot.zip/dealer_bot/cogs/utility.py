"""
Утилитарные команды — по мелочи, но то, что нужно любому боту:
/ping — жив ли бот и какая задержка
/help — список команд
/stats — лёгкая статистика активности на сервере
/restart — аккуратно закрыть БД и перезапустить бота (только администраторам)
"""

import time

import disnake
from disnake.ext import commands

import db

START_TIME = time.time()


def _format_uptime(seconds: float) -> str:
    seconds = int(seconds)
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    parts = []
    if days:
        parts.append(f"{days}д")
    if hours:
        parts.append(f"{hours}ч")
    if minutes:
        parts.append(f"{minutes}м")
    if not parts:
        parts.append(f"{seconds}с")
    return " ".join(parts)


class UtilityCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.slash_command(name="ping", description="Проверить, жив ли бот, и задержку до Discord")
    async def ping_slash(self, inter: disnake.ApplicationCommandInteraction):
        embed = disnake.Embed(title="🏓 Понг!", color=0x57F287)
        embed.add_field(name="Задержка", value=f"{round(self.bot.latency * 1000)} мс", inline=True)
        embed.add_field(name="Аптайм", value=_format_uptime(time.time() - START_TIME), inline=True)
        await inter.response.send_message(embed=embed)

    @commands.slash_command(name="help", description="Список всех команд бота")
    async def help_slash(self, inter: disnake.ApplicationCommandInteraction):
        embed = disnake.Embed(title="📋 Команды бота", color=0x5865F2)
        embed.add_field(
            name="🎙️ Голосовые комнаты",
            value="Панель управления — кнопки в настроенном канале.\n`/voice_unban`",
            inline=False,
        )
        embed.add_field(
            name="🛡️ Модерация",
            value="`/warn` `/warnings` `/unwarn` `/mute` `/unmute` `/kick` `/ban` `/clear` `/re`",
            inline=False,
        )
        embed.add_field(
            name="ℹ️ Информация",
            value="`/info user` `/info server` `/ping` `/stats`",
            inline=False,
        )
        embed.set_footer(text="Анкеты, тикеты и предложения оформляются кнопками в своих каналах.")
        await inter.response.send_message(embed=embed)

    @commands.slash_command(name="stats", description="Статистика активности бота на этом сервере")
    async def stats_slash(self, inter: disnake.ApplicationCommandInteraction):
        await inter.response.defer()
        guild_id = inter.guild.id

        voice_rooms = await db.count_active_voice_rooms(guild_id)
        open_tickets = await db.count_open_tickets(guild_id)
        pending_suggestions = await db.count_pending_suggestions(guild_id)
        active_warnings = await db.count_active_warnings(guild_id)

        embed = disnake.Embed(title="📊 Статистика сервера", color=0x5865F2)
        embed.add_field(name="🎙️ Активных голосовых комнат", value=str(voice_rooms), inline=True)
        embed.add_field(name="🎫 Открытых тикетов", value=str(open_tickets), inline=True)
        embed.add_field(name="💡 Предложений на рассмотрении", value=str(pending_suggestions), inline=True)
        embed.add_field(name="⚠️ Активных предупреждений", value=str(active_warnings), inline=True)
        embed.add_field(name="👥 Участников сервера", value=str(inter.guild.member_count), inline=True)
        await inter.edit_original_response(embed=embed)

    @commands.slash_command(name="restart", description="Аккуратно перезапустить бота (только администраторам)")
    async def restart_slash(self, inter: disnake.ApplicationCommandInteraction):
        if not inter.author.guild_permissions.administrator:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Требуются права администратора.", ephemeral=True)
            return
        await inter.response.send_message(
            "🔄 Перезапускаюсь... Если бот запущен через цикл автоперезапуска "
            "(см. рекомендации по Termux) — вернусь в течение нескольких секунд."
        )
        await db.close()
        await self.bot.close()


def setup(bot: commands.Bot):
    bot.add_cog(UtilityCog(bot))
