"""
Объявления (реклама/анонсы) — два независимых механизма:

1. Периодическая рассылка в конкретные каналы (config["channel_ids"]) —
   например анкета или предложения — раз в interval_seconds.
2. Мгновенная реклама в КАЖДУЮ новую временную голосовую комнату сразу
   при её создании (config["post_on_voice_create"]) — не переспамливает
   комнаты, где люди уже сидят, срабатывает только один раз на комнату,
   в момент когда она появилась.

Объявления берутся из config["ads"] по кругу, если их несколько.
"""

import logging

import disnake
from disnake.ext import commands, tasks

from dealer_bot import get_advertisement_config

log = logging.getLogger("ads_cog")


class AdsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._ad_index: dict[int, int] = {}  # guild_id -> индекс следующего объявления по кругу
        self.periodic_ads_loop.start()

    def cog_unload(self):
        self.periodic_ads_loop.cancel()

    @staticmethod
    def _build_embed(ad: dict) -> disnake.Embed:
        embed = disnake.Embed(
            title=ad.get("title"),
            description=ad.get("description"),
            color=ad.get("color", 0x5865F2),
        )
        if ad.get("image"):
            embed.set_image(url=ad["image"])
        if ad.get("footer"):
            embed.set_footer(text=ad["footer"])
        return embed

    def _next_ad_embed(self, guild_id: int, ads: list[dict]) -> disnake.Embed | None:
        if not ads:
            return None
        idx = self._ad_index.get(guild_id, 0) % len(ads)
        self._ad_index[guild_id] = idx + 1
        return self._build_embed(ads[idx])

    # ==================== мгновенная реклама при создании войса ====================
    @commands.Cog.listener()
    async def on_temp_voice_created(self, channel: disnake.VoiceChannel, guild: disnake.Guild, member: disnake.Member):
        config = get_advertisement_config(guild.id)
        if not config.get("enabled") or not config.get("post_on_voice_create", True):
            return
        embed = self._next_ad_embed(guild.id, config.get("ads") or [])
        if not embed:
            return
        try:
            await channel.send(embed=embed)
        except disnake.HTTPException as e:
            log.warning("Не удалось отправить рекламу в новую комнату %s: %s", channel.id, e)

    # ==================== периодическая рассылка по выбранным каналам ====================
    @tasks.loop(minutes=1)
    async def periodic_ads_loop(self):
        """Крутится раз в минуту, но реально рассылает объявление в
        конкретном сервере только когда для него истёк его собственный
        interval_seconds — так у разных серверов может быть разная частота."""
        tick = self.periodic_ads_loop.current_loop
        for guild in self.bot.guilds:
            config = get_advertisement_config(guild.id)
            if not config.get("enabled"):
                continue
            channel_ids = config.get("channel_ids", [])
            if not channel_ids:
                continue
            interval_minutes = max(1, config.get("interval_seconds", 3600) // 60)
            if tick % interval_minutes != 0:
                continue

            embed = self._next_ad_embed(guild.id, config.get("ads") or [])
            if not embed:
                continue
            for channel_id in channel_ids:
                channel = guild.get_channel(channel_id)
                if not channel:
                    continue
                try:
                    await channel.send(embed=embed)
                except disnake.HTTPException as e:
                    log.warning("Не удалось отправить объявление в канал %s: %s", channel_id, e)

    @periodic_ads_loop.before_loop
    async def before_periodic_ads_loop(self):
        await self.bot.wait_until_ready()


def setup(bot: commands.Bot):
    bot.add_cog(AdsCog(bot))
