import logging

import disnake
from disnake.ext import commands
import asyncio

import db
from dealer_bot import (
    get_ticket_config,
    user_tickets
)

log = logging.getLogger("tickets_cog")


# ===== МОДАЛЬНОЕ ОКНО ДЛЯ ТИКЕТА =====
class TicketModal(disnake.ui.Modal):
    def __init__(self, channel_id, topic_value, topic_label):
        self.channel_id = channel_id
        self.topic_value = topic_value
        self.topic_label = topic_label
        config = get_ticket_config(channel_id)
        self.config = config

        fields = config.get("modal_fields") or [{
            "custom_id": "description", "label": "Краткое описание проблемы",
            "placeholder": "Опишите суть обращения...", "style": "paragraph",
            "min_length": 5, "max_length": 1000, "required": True,
        }]
        fields = fields[:5]  # Discord разрешает не больше 5 полей в модальном окне

        components = []
        for field_config in fields:
            style = disnake.TextInputStyle.paragraph if field_config.get("style") == "paragraph" else disnake.TextInputStyle.short
            components.append(disnake.ui.TextInput(
                label=field_config["label"],
                placeholder=field_config.get("placeholder", ""),
                min_length=field_config.get("min_length", 1),
                max_length=field_config.get("max_length", 1000),
                required=field_config.get("required", True),
                style=style,
                custom_id=field_config["custom_id"],
            ))
        self.field_configs = fields

        modal_title = config.get("modal_title", "📝 Создание тикета")
        super().__init__(title=modal_title[:45], components=components)

    async def callback(self, inter: disnake.ModalInteraction):
        author = inter.author
        guild = inter.guild
        channel_id = self.channel_id

        key = (author.id, channel_id)
        if key in user_tickets:
            existing_channel = guild.get_channel(user_tickets[key])
            if existing_channel:
                await inter.response.send_message(
                    f"<:Other_problem:1528536802720350370> У вас уже есть открытый тикет в этом канале: {existing_channel.mention}. Закройте его, прежде чем создавать новый.",
                    ephemeral=True,
                    delete_after=10
                )
                return
            else:
                del user_tickets[key]

        config = self.config
        if not config:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Ошибка конфигурации!", ephemeral=True, delete_after=10)
            return

        # Собираем все заполненные поля — их может быть сколько угодно,
        # в отличие от старой версии с одним хардкодным "description".
        submitted = {fc["custom_id"]: inter.text_values.get(fc["custom_id"], "") for fc in self.field_configs}

        category = guild.get_channel(config["category_id"])
        if not category:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Категория для тикетов не найдена!", ephemeral=True, delete_after=10)
            return

        topic_label = self.topic_label or "Обращение"
        ticket_num = await db.next_ticket_number(channel_id)

        channel_name = f"ticket-{ticket_num}-{topic_label}".lower().replace(" ", "-").replace(":", "")

        try:
            overwrites = {
                guild.default_role: disnake.PermissionOverwrite(read_messages=False),
                author: disnake.PermissionOverwrite(read_messages=True, send_messages=True, attach_files=True, embed_links=True),
            }
            for role_id in config["support_roles"]:
                role = guild.get_role(role_id)
                if role:
                    overwrites[role] = disnake.PermissionOverwrite(read_messages=True, send_messages=True)

            ticket_channel = await guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Тема: {topic_label} | Создатель: {author}"
            )
        except disnake.HTTPException as e:
            log.error("Не удалось создать канал тикета: %s", e)
            await inter.response.send_message(f"<:Other_problem:1528536802720350370> Ошибка при создании канала: {e}", ephemeral=True, delete_after=10)
            return

        user_tickets[key] = ticket_channel.id

        ticket_embed_title = config.get("ticket_embed_title", "🎫 Ваш тикет создан!")
        ticket_embed_color = config.get("ticket_embed_color", 0x00FF00)
        ticket_embed_footer = config.get("ticket_embed_footer", None)

        embed = disnake.Embed(title=ticket_embed_title, color=ticket_embed_color)
        embed.add_field(name="Тема", value=topic_label, inline=False)
        for field_config in self.field_configs:
            value = submitted.get(field_config["custom_id"]) or "Не указано"
            embed.add_field(name=field_config["label"], value=value, inline=False)
        embed.add_field(name="\u200b", value="Поддержка ответит вам в ближайшее время.", inline=False)

        if ticket_embed_footer:
            footer_text = ticket_embed_footer.replace("{author}", str(author))
            embed.set_footer(text=footer_text, icon_url=author.display_avatar.url)
            embed.timestamp = disnake.utils.utcnow()
        else:
            embed.set_footer(text=f"Создатель: {author}", icon_url=author.display_avatar.url)
            embed.timestamp = disnake.utils.utcnow()

        close_label = config.get("close_button_label", "Закрыть тикет")
        close_style_name = config.get("close_button_style", "danger")
        close_style = getattr(disnake.ButtonStyle, close_style_name, disnake.ButtonStyle.danger)
        close_emoji = config.get("close_button_emoji", None)

        view = TicketCloseView(ticket_channel.id, author.id, channel_id, close_label, close_style, close_emoji)

        # Персистентно сохраняем тикет — иначе кнопка "Закрыть" в этом
        # канале перестанет отвечать после рестарта бота (View не
        # переотправляется сама, в отличие от панели входа).
        await db.save_ticket(guild.id, ticket_channel.id, author.id, channel_id,
                              close_label, close_style_name, close_emoji)
        inter.bot.add_view(view)

        support_mentions = ", ".join([f"<@&{role_id}>" for role_id in config["support_roles"]])

        await ticket_channel.send(
            content=f"{author.mention}, {support_mentions}",
            embed=embed,
            view=view
        )

        await inter.response.send_message(
            f"✅ Тикет создан! Перейдите в канал {ticket_channel.mention}",
            ephemeral=True,
            delete_after=10
        )

# ===== КНОПКА СОЗДАНИЯ ТИКЕТА =====
class TicketCreateButton(disnake.ui.Button):
    def __init__(self, channel_id):
        self.channel_id = channel_id
        config = get_ticket_config(channel_id)
        label = config.get("button_label", "🎫 Создать тикет")
        style_name = config.get("button_style", "green")
        style = getattr(disnake.ButtonStyle, style_name, disnake.ButtonStyle.green)
        emoji = config.get("button_emoji", None)
        super().__init__(label=label, style=style, emoji=emoji, custom_id=f"create_ticket_{channel_id}")

    async def callback(self, inter: disnake.MessageInteraction):
        author = inter.author
        channel_id = self.channel_id

        key = (author.id, channel_id)
        if key in user_tickets:
            existing_channel = inter.guild.get_channel(user_tickets[key])
            if existing_channel:
                await inter.response.send_message(
                    f"<:Other_problem:1528536802720350370> У вас уже есть открытый тикет в этом канале: {existing_channel.mention}. Закройте его, прежде чем создавать новый.",
                    ephemeral=True,
                    delete_after=10
                )
                return
            else:
                del user_tickets[key]

        config = get_ticket_config(channel_id)
        if not config:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Ошибка конфигурации!", ephemeral=True, delete_after=10)
            return

        if config.get("mode") == "modal":
            default_label = config.get("default_topic_label", "Обращение")
            default_value = config.get("default_topic_value", "default")
            await inter.response.send_modal(TicketModal(channel_id, default_value, default_label))
        else:
            select = disnake.ui.Select(
                placeholder="Выберите тему обращения...",
                min_values=1,
                max_values=1,
                options=[
                    disnake.SelectOption(
                        label=topic["label"],
                        value=topic["value"],
                        description=topic.get("description", ""),
                        emoji=topic.get("emoji", None)
                    )
                    for topic in config["topics"]
                ],
                custom_id=f"ticket_topic_select_{channel_id}"
            )

            async def select_callback(inter2: disnake.MessageInteraction):
                try:
                    await inter2.message.delete()
                except disnake.HTTPException:
                    pass
                selected_value = select.values[0]
                topic_label = next((t["label"] for t in config["topics"] if t["value"] == selected_value), "Обращение")
                await inter2.response.send_modal(TicketModal(channel_id, selected_value, topic_label))

            select.callback = select_callback

            view = disnake.ui.View(timeout=60)
            view.add_item(select)
            await inter.response.send_message(
                "Выберите тему тикета:",
                ephemeral=True,
                view=view,
                delete_after=10
            )

class TicketCreateView(disnake.ui.View):
    def __init__(self, channel_id):
        super().__init__(timeout=None)
        self.add_item(TicketCreateButton(channel_id))

# ===== КНОПКА ЗАКРЫТИЯ ТИКЕТА =====
class TicketCloseButton(disnake.ui.Button):
    def __init__(self, channel_id, user_id, source_channel_id, label, style, emoji):
        self.channel_id = channel_id
        self.user_id = user_id
        self.source_channel_id = source_channel_id
        super().__init__(label=label, style=style, custom_id=f"close_ticket_{channel_id}", emoji=emoji)

    async def callback(self, inter: disnake.MessageInteraction):
        channel = inter.channel
        if not isinstance(channel, disnake.TextChannel) or not channel.name.startswith("ticket-"):
            await inter.response.send_message("<:Other_problem:1528536802720350370> Этот канал не является тикетом.", ephemeral=True)
            return

        config = get_ticket_config(self.source_channel_id)
        support_roles = config.get("support_roles", [])

        is_creator = inter.author.id == self.user_id
        is_support = False
        for role_id in support_roles:
            role = inter.guild.get_role(role_id)
            if role and role in inter.author.roles:
                is_support = True
                break

        if not is_creator and not is_support:
            await inter.response.send_message("<:Other_problem:1528536802720350370> У вас нет прав на закрытие этого тикета.", ephemeral=True)
            return

        key = (self.user_id, self.source_channel_id)
        if key in user_tickets:
            del user_tickets[key]
        await db.remove_ticket(channel.id)

        await inter.response.send_message("🔒 Тикет будет закрыт через 5 секунд...", ephemeral=False)
        await asyncio.sleep(5)
        try:
            await channel.delete()
        except disnake.HTTPException as e:
            log.warning("Не удалось удалить канал тикета %s: %s", channel.id, e)

class TicketCloseView(disnake.ui.View):
    def __init__(self, channel_id, user_id, source_channel_id, label, style, emoji):
        super().__init__(timeout=None)
        self.add_item(TicketCloseButton(channel_id, user_id, source_channel_id, label, style, emoji))

# ===== КОГ =====
class TicketsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self.initialize())

    # Публичный метод для отправки панели тикетов (без очистки)
    async def send_ticket_panel(self, channel):
        """Отправляет новую панель тикетов в указанный канал"""
        channel_id = channel.id
        config = get_ticket_config(channel_id)
        if not config:
            return

        embed_title = config.get("embed_title", "🎫 Система поддержки")
        embed_description = config.get("embed_description", "Нажмите на кнопку ниже, чтобы создать тикет.")
        embed_color = config.get("embed_color", 0x00FF00)
        embed_footer = config.get("embed_footer", None)

        if config.get("mode") == "menu":
            embed_description += " Выберите тему и опишите проблему."
        else:
            embed_description += " Опишите вашу проблему."

        embed_description += "\n\n > ⚠️ **Внимание!** перед заполнением заявки ознакомьтесь с правилами и политикой сервера"

        embed = disnake.Embed(
            title=embed_title,
            description=embed_description,
            color=embed_color
        )
        if embed_footer:
            embed.set_footer(text=embed_footer)

        view = TicketCreateView(channel_id)
        new_msg = await channel.send(embed=embed, view=view)

        # Удаляем старую панель по ID из БД (не из памяти — иначе после
        # рестарта бота старая панель "терялась" и оставалась висеть рядом
        # с новой, потому что словарь в памяти обнулялся).
        old_id = await db.get_channel_panel(channel_id)
        if old_id:
            try:
                old_msg = await channel.fetch_message(old_id)
                await old_msg.delete()
            except disnake.HTTPException as e:
                # Раньше здесь было "except: pass" — ошибка исчезала молча,
                # и старая панель могла копиться в канале без единого следа
                # в логах о том, почему. Самая частая причина — у бота нет
                # права "Управление сообщениями" именно в этом канале.
                log.warning("Не удалось удалить старую панель тикетов (id=%s) в канале %s: %s",
                            old_id, channel_id, e)

        await db.save_channel_panel(channel_id, new_msg.id)

    async def refresh_ticket_button(self, channel):
        """Обновляет панель тикетов (используется по команде !обновить).
        Раньше тут был полный channel.purge(limit=None) — медленная и
        избыточная операция, ведь send_ticket_panel и так убирает старую
        панель точечно, по сохранённому ID."""
        await self.send_ticket_panel(channel)

    async def initialize(self):
        """Восстанавливает открытые тикеты из БД — без этого кнопка "Закрыть"
        в уже созданных тикет-каналах перестаёт отвечать после рестарта бота."""
        await self.bot.wait_until_ready()
        await db.init()
        restored = 0
        for guild_id, ticket_channel_id, author_id, source_channel_id, label, style_name, emoji in await db.load_all_tickets():
            guild = self.bot.get_guild(guild_id)
            channel = guild.get_channel(ticket_channel_id) if guild else None
            if not channel:
                # тикет закрыли/удалили, пока бот был выключен — чистим хвост
                await db.remove_ticket(ticket_channel_id)
                continue
            user_tickets[(author_id, source_channel_id)] = ticket_channel_id
            style = getattr(disnake.ButtonStyle, style_name, disnake.ButtonStyle.danger)
            view = TicketCloseView(ticket_channel_id, author_id, source_channel_id, label, style, emoji)
            self.bot.add_view(view)
            restored += 1
        if restored:
            log.info("Восстановлено %d открытых тикетов после рестарта.", restored)

# ===== ФУНКЦИЯ ДЛЯ ЗАГРУЗКИ КОГА =====
def setup(bot):
    bot.add_cog(TicketsCog(bot))