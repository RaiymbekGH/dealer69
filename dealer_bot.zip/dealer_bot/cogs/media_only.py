"""
Удаляет сообщения участников в каналах из MEDIA_ONLY_CHANNELS
(dealer_bot.py), не подходящие под разрешённые для этого канала типы
контента (картинки / видео / файлы / опросы / ссылки) — для каналов
вроде #скриншоты (только фото), #клипы (только видео) и т.п.

Совмещено с авто-ветками (раньше был отдельный cogs/auto_thread.py):
если для канала включено "auto_thread", под каждым сообщением, которое
ПРОШЛО фильтр (не удалено), сама открывается ветка-обсуждение. Слияние
специально сделано в одном обработчике on_message, а не как два разных
слушателя — иначе решение "удалить" и решение "создать ветку" гонялись
бы независимо, и ветка могла попытаться открыться на уже удалённом
сообщении.

Администраторов фильтр не трогает (используются с полными правами).
"""

import logging
import re

import disnake
from disnake.ext import commands

from dealer_bot import MEDIA_ONLY_CHANNELS

log = logging.getLogger("media_only_cog")

IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".webp")
VIDEO_EXTENSIONS = (".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v")
LINK_RE = re.compile(r"https?://\S+", re.IGNORECASE)

MAX_THREAD_NAME = 100


def _is_image(attachment: disnake.Attachment) -> bool:
    if attachment.content_type and attachment.content_type.startswith("image/"):
        return True
    return attachment.filename.lower().endswith(IMAGE_EXTENSIONS)


def _is_video(attachment: disnake.Attachment) -> bool:
    if attachment.content_type and attachment.content_type.startswith("video/"):
        return True
    return attachment.filename.lower().endswith(VIDEO_EXTENSIONS)


def _message_allowed(message: disnake.Message, allowed: dict) -> bool:
    """allowed — словарь вида {"images": bool, "videos": bool, "files": bool,
    "polls": bool, "links": bool, "auto_thread": bool}. Ключ, которого нет в
    словаре, считается разрешённым по умолчанию (кроме auto_thread — тот по
    умолчанию выключен) — то есть для контента достаточно перечислить только
    то, что хотите ЗАПРЕТИТЬ."""
    images = [a for a in message.attachments if _is_image(a)]
    videos = [a for a in message.attachments if _is_video(a)]
    files = [a for a in message.attachments if not _is_image(a) and not _is_video(a)]
    has_poll = getattr(message, "poll", None) is not None
    has_link = bool(LINK_RE.search(message.content or ""))

    if images and not allowed.get("images", True):
        return False
    if videos and not allowed.get("videos", True):
        return False
    if files and not allowed.get("files", True):
        return False
    if has_poll and not allowed.get("polls", True):
        return False
    if has_link and not allowed.get("links", True):
        return False

    return bool(images or videos or files or has_poll or has_link)  # голый текст без вложений всегда удаляется


def _thread_name(message: disnake.Message) -> str:
    text = message.content.strip()
    if text:
        return text[:MAX_THREAD_NAME]
    return f"Обсуждение — {message.author.display_name}"[:MAX_THREAD_NAME]


class MediaOnlyCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot or not message.guild:
            return
        allowed = MEDIA_ONLY_CHANNELS.get(message.channel.id)
        if allowed is None:
            return
        if message.author.guild_permissions.administrator:
            return

        if not _message_allowed(message, allowed):
            try:
                await message.delete()
            except disnake.HTTPException as e:
                log.warning("Не удалось удалить сообщение в медиа-канале %s: %s", message.channel.id, e)
            return  # сообщение удалено — ветку под ним создавать не на чем

        if allowed.get("auto_thread", False):
            try:
                await message.create_thread(name=_thread_name(message))
            except disnake.HTTPException as e:
                log.warning(
                    "Не удалось создать ветку для сообщения %s в канале %s: %s",
                    message.id, message.channel.id, e,
                )


def setup(bot: commands.Bot):
    bot.add_cog(MediaOnlyCog(bot))
