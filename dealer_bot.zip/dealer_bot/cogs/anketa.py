import asyncio
import logging
import time

import disnake
from disnake.ext import commands

import db
from dealer_bot import (
    get_anketa_config,
    button_messages
)
from restrictions import has_flag as mod_has_flag, get_extra_anketa_cooldown as mod_get_extra_anketa_cooldown

log = logging.getLogger("anketa_cog")


# ===== ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ: создаёт embed =====
def create_invite_embed(config):
    return disnake.Embed(
        title=config["title"],
        description=config["invite_text"] + "\n\n > ⚠️ **Внимание!** перед заполнением заявки ознакомьтесь с правилами и политикой сервера",
        color=config["color"]
    )

# ===== ФУНКЦИЯ ДЛЯ ОЧИСТКИ СТАРЫХ ПАНЕЛЕЙ =====
async def clean_old_anketa_panels(channel):
    """Удаляет старую панель. ID уже сохранён в button_messages при
    предыдущей отправке — удаляем её напрямую, без сканирования истории
    канала (что было медленно и держало анкету в очереди позади других
    каналов при старте бота)."""
    deleted = 0
    old_id = button_messages.get(channel.id)
    if old_id:
        try:
            old_msg = await channel.fetch_message(old_id)
            await old_msg.delete()
            deleted = 1
        except disnake.HTTPException:
            pass  # сообщение уже удалено вручную или не найдено — не страшно
        return deleted

    # Fallback на первый запуск / если ID почему-то не сохранился — тогда
    # действительно приходится сканировать историю, но это разовый случай.
    prefix = "anketa_button_"
    try:
        async for message in channel.history(limit=100):
            if message.components:
                for action_row in message.components:
                    for component in action_row.children:
                        if hasattr(component, 'custom_id') and component.custom_id and component.custom_id.startswith(prefix):
                            await message.delete()
                            deleted += 1
                            break
                    else:
                        continue
                    break
    except disnake.HTTPException as e:
        log.warning("Ошибка при очистке старых панелей анкеты в канале %s: %s", channel.id, e)
    return deleted

# ===== МОДАЛЬНОЕ ОКНО =====
class AnketaModal(disnake.ui.Modal):
    def __init__(self, channel_id):
        self.channel_id = channel_id
        config = get_anketa_config(channel_id)
        components = []
        for field_config in config["fields"]:
            style = disnake.TextInputStyle.paragraph if field_config["style"] == "paragraph" else disnake.TextInputStyle.short
            text_input = disnake.ui.TextInput(
                label=field_config["label"],
                placeholder=field_config["placeholder"],
                min_length=field_config["min_length"],
                max_length=field_config["max_length"],
                required=field_config["required"],
                style=style,
                custom_id=field_config["custom_id"]
            )
            components.append(text_input)
        super().__init__(title="Заполнение формы", components=components)
        self.config = config

    async def callback(self, inter: disnake.ModalInteraction):
        config = self.config
        if not config:
            return

        # Ограничения по очкам предупреждений (см. cogs/moderation.py) — не
        # завязаны на роли, считаются каждый раз заново по текущим очкам.
        if await mod_has_flag(inter.guild.id, inter.author.id, "no_anketa"):
            await inter.response.send_message(
                "<:Other_problem:1528536802720350370> Доступ к созданию анкет временно ограничен из-за предупреждений.", ephemeral=True,
            )
            return

        cooldown = config.get("cooldown_seconds", 0)
        cooldown = max(cooldown, await mod_get_extra_anketa_cooldown(inter.guild.id, inter.author.id))
        if cooldown:
            cooldown_key = f"anketa:{self.channel_id}"
            last = await db.get_command_cooldown(inter.guild.id, inter.author.id, cooldown_key)
            now = time.time()
            if last is not None and now - last < cooldown:
                wait_left = int(cooldown - (now - last))
                hours, minutes = divmod(wait_left // 60, 60)
                await inter.response.send_message(
                    f"<a:Loading:1528999376549314691> Следующую анкету здесь можно подать через {hours} ч {minutes} мин.", ephemeral=True,
                )
                return

        embed = disnake.Embed(color=config["color"])
        embed.set_thumbnail(url=inter.author.display_avatar.url)
        embed.set_author(name=inter.author.display_name, icon_url=inter.author.display_avatar.url)

        for field_config in config["fields"]:
            value = inter.text_values.get(field_config["custom_id"], "Не указано")
            embed.add_field(name=field_config["label"], value=value, inline=False)

        embed.set_footer(text="Создано")
        embed.timestamp = disnake.utils.utcnow()

        await inter.response.send_message("✅ Успешно опубликована.", ephemeral=True, delete_after=5)

        content_template = config.get("post_content", "{mention}")
        author_mention = inter.author.mention
        content = content_template.format(mention=author_mention)

        role_ids = config.get("mention_roles", [])
        if role_ids:
            roles_mention_text = " ".join([f"<@&{role_id}>" for role_id in role_ids])
            final_content = f"{roles_mention_text}, {content}"
        else:
            final_content = content

        channel_id = self.channel_id
        cog = inter.bot.get_cog("AnketaCog")

        # Публикация анкеты и удаление старой кнопки друг от друга не
        # зависят — гоняем их параллельно, а не по очереди, это экономит
        # один полный сетевой круг до Discord. Новую кнопку шлём только
        # ПОСЛЕ того, как анкета точно опубликована — иначе можно словить
        # гонку и кнопка окажется выше анкеты в истории канала.
        tasks = [inter.channel.send(content=final_content, embed=embed)]
        if cog:
            tasks.append(cog.clean_old_anketa_panels(inter.channel))
        results = await asyncio.gather(*tasks, return_exceptions=True)

        if isinstance(results[0], Exception):
            log.error("Не удалось опубликовать анкету в канале %s: %s", inter.channel.id, results[0])
            return  # анкета не ушла — кнопку переносить незачем

        if cooldown:
            await db.set_command_cooldown(inter.guild.id, inter.author.id, f"anketa:{channel_id}", time.time())

        if cog:
            try:
                await cog.send_anketa_panel(inter.channel)
            except disnake.HTTPException as e:
                log.warning("Не удалось обновить кнопку анкеты в канале %s: %s", inter.channel.id, e)

# ===== КНОПКА И VIEW =====
class AnketaButton(disnake.ui.Button):
    def __init__(self, channel_id):
        config = get_anketa_config(channel_id)
        label = config.get("button_label", "Оставить заявку")
        style_name = config.get("button_style", "primary")
        style = getattr(disnake.ButtonStyle, style_name, disnake.ButtonStyle.primary)
        super().__init__(label=label, style=style, custom_id=f"anketa_button_{channel_id}")
        self.channel_id = channel_id

    async def callback(self, inter: disnake.MessageInteraction):
        await inter.response.send_modal(AnketaModal(self.channel_id))

class AnketaView(disnake.ui.View):
    def __init__(self, channel_id):
        super().__init__(timeout=None)
        self.add_item(AnketaButton(channel_id))

# ===== КОГ =====
class AnketaCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.loop.create_task(self._init_db())

    async def _init_db(self):
        await self.bot.wait_until_ready()
        await db.init()

    # Публичный метод для очистки старых панелей
    async def clean_old_anketa_panels(self, channel):
        return await clean_old_anketa_panels(channel)

    # Публичный метод для отправки новой панели
    async def send_anketa_panel(self, channel):
        """Отправляет новую панель анкеты в указанный канал (без удаления старых)"""
        channel_id = channel.id
        config = get_anketa_config(channel_id)
        if not config:
            return

        embed = create_invite_embed(config)
        view = AnketaView(channel_id)

        new_msg = await channel.send(embed=embed, view=view)
        button_messages[channel_id] = new_msg.id

    async def refresh_anketa_button(self, channel):
        """Обновляет панель: удаляет старые и отправляет новую (используется командой /re из cogs/moderation.py)"""
        await clean_old_anketa_panels(channel)
        await self.send_anketa_panel(channel)

def setup(bot):
    bot.add_cog(AnketaCog(bot))