"""
Модерация сервера — слэш-команды.

/re                                  — обновляет все панели (анкета/тикеты/предложения/
                                        настройки войсов) в ТЕКУЩЕМ канале, смотря что там есть
/clear count [member]                — удаляет сообщения в канале, опционально только от одного участника
/warn member level reason [duration] — выдать предупреждение (см. правила уровней ниже)
/warnings member                     — список активных предупреждений участника
/unwarn id                           — снять конкретное предупреждение по его номеру
/mute member duration [reason]       — тайм-аут
/unmute member                       — снять тайм-аут
/kick member [reason]
/ban member [reason]
/info user [member]                  — информация об участнике (или о себе)
/info server                         — информация о сервере

Уровни предупреждений:
  1 — временный, СРОК ОБЯЗАТЕЛЕН (например 7d)
  2 — временный ИЛИ бессрочный на выбор (срок можно не указывать)
  3 — всегда бессрочный, срок не указывается вообще

Срок — строка вида <число><единица>: s/с, m/м, h/ч, d/д, w/н. Например: 30m, 12h, 7d, 2w.

ПРАВА И КУЛДАУНЫ настраиваются в dealer_bot.py -> MODERATION_CONFIGS[guild_id]:
  "mod_roles"        — роли с полным доступом ко всему без кулдаунов (+ администраторы)
  "role_permissions" — гибко: каждая роль -> список команд -> (уровни для warn) + кулдаун в секундах.
                        Если ролей несколько — берётся самый широкий доступ и минимальный кулдаун.
  "punishments"      — пороги очков предупреждений -> автонаказание (role/timeout/kick/ban).
"""

import datetime
import logging
import re
import time

import disnake
from disnake.ext import commands, tasks

import db
from dealer_bot import (
    get_moderation_config,
    ANKETA_CONFIGS, TICKET_CONFIGS, SUGGESTION_CONFIGS,
    get_voice_config,
)
from cogs.voice import send_or_update_panel
from restrictions import get_active_flags

log = logging.getLogger("moderation_cog")

DURATION_RE = re.compile(r"^(\d+)\s*(s|sec|с|m|min|м|h|ч|d|д|w|н)$", re.IGNORECASE)
DURATION_UNITS = {
    "s": 1, "sec": 1, "с": 1,
    "m": 60, "min": 60, "м": 60,
    "h": 3600, "ч": 3600,
    "d": 86400, "д": 86400,
    "w": 604800, "н": 604800,
}


def parse_duration(token: str) -> int | None:
    """'7d' / '3h' / '30m' -> секунды. None, если не похоже на срок."""
    match = DURATION_RE.match(token.strip())
    if not match:
        return None
    amount, unit = match.groups()
    return int(amount) * DURATION_UNITS[unit.lower()]


def format_duration(seconds: float) -> str:
    seconds = int(seconds)
    days, seconds = divmod(seconds, 86400)
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    parts = []
    if days:
        parts.append(f"{days}д")
    if hours:
        parts.append(f"{hours}ч")
    if minutes:
        parts.append(f"{minutes}м")
    if not parts:
        parts.append(f"{seconds}с")
    return " ".join(parts)


def _is_full_moderator(config: dict, member: disnake.Member) -> bool:
    if member.guild_permissions.administrator:
        return True
    return any(role.id in config.get("mod_roles", []) for role in member.roles)


def _is_staff(config: dict, member: disnake.Member) -> bool:
    """Есть ли у участника вообще хоть какая-то модераторская роль (для
    решения, показывать ли ему предупреждения ДРУГИХ в /info)."""
    if _is_full_moderator(config, member):
        return True
    role_ids = {r.id for r in member.roles}
    return any(entry.get("role_id") in role_ids for entry in config.get("role_permissions", []))


# ==================== переиспользуемая логика выдачи предупреждения ====================
# Вынесено на уровень модуля (не методы класса), чтобы cogs/automod.py могло
# выдавать предупреждения через ТУ ЖЕ логику (очки/сроки/автонаказания/лог),
# что и команда /warn, не дублируя её.

async def apply_punishments(guild: disnake.Guild, member: disnake.Member,
                             config: dict, old_total: int, new_total: int) -> list[dict]:
    """Применяет только ВНОВЬ пересечённые пороги (между old_total и new_total),
    чтобы одно и то же наказание не срабатывало повторно на каждый следующий варн."""
    triggered = [p for p in config.get("punishments", []) if old_total < p["points"] <= new_total]
    triggered.sort(key=lambda p: p["points"])
    for p in triggered:
        action = p.get("action")
        try:
            if action == "role":
                role = guild.get_role(p.get("role_id"))
                if role:
                    await member.add_roles(role, reason=f"Автонаказание: {new_total} очков предупреждений")
            elif action == "timeout":
                until = disnake.utils.utcnow() + datetime.timedelta(seconds=p.get("duration_seconds", 3600))
                await member.timeout(until=until, reason=f"Автонаказание: {new_total} очков предупреждений")
            elif action == "kick":
                await member.kick(reason=f"Автонаказание: {new_total} очков предупреждений")
            elif action == "ban":
                await member.ban(reason=f"Автонаказание: {new_total} очков предупреждений")
        except disnake.HTTPException as e:
            log.warning("Не удалось применить автонаказание %s для %s: %s", action, member.id, e)
    return triggered


def describe_punishment(p: dict) -> str:
    action = p.get("action")
    if action == "role":
        return f"роль <@&{p.get('role_id')}>"
    if action == "timeout":
        return f"тайм-аут {format_duration(p.get('duration_seconds', 3600))}"
    if action == "kick":
        return "кик"
    if action == "ban":
        return "бан"
    return str(action)


async def log_action(guild: disnake.Guild, config: dict, embed: disnake.Embed):
    log_channel_id = config.get("log_channel_id")
    if not log_channel_id:
        return
    channel = guild.get_channel(log_channel_id)
    if channel:
        try:
            await channel.send(embed=embed)
        except disnake.HTTPException:
            pass


# get_active_flags / has_flag / get_extra_anketa_cooldown / get_soft_slowmode_seconds
# переехали в restrictions.py (отдельный модуль без зависимостей от cogs/*,
# чтобы voice.py/anketa.py/suggestions.py/automod.py могли использовать их
# без циклического импорта через moderation.py).


async def issue_warning(guild: disnake.Guild, member: disnake.Member, moderator: disnake.abc.User,
                         level: int, reason: str, duration_seconds: int | None,
                         notify_channel: disnake.abc.Messageable | None = None) -> int:
    """Полный цикл выдачи предупреждения: очки, срок, ЛС участнику, автонаказания,
    лог. Используется и командой /warn, и автомодерацией (cogs/automod.py).
    Возвращает id созданного предупреждения."""
    config = get_moderation_config(guild.id)
    points = config.get("level_points", {}).get(level, level)
    expires_at = time.time() + duration_seconds if duration_seconds else None

    old_total = await db.get_total_points(guild.id, member.id)
    warning_id = await db.add_warning(guild.id, member.id, moderator.id, level, points, reason, expires_at)
    new_total = await db.get_total_points(guild.id, member.id)

    expiry_text = f"через {format_duration(duration_seconds)}" if duration_seconds else "бессрочно"
    embed = disnake.Embed(
        title=f"⚠️ Предупреждение #{warning_id}",
        description=(
            f"**Участник:** {member.mention}\n**Уровень:** {level}\n"
            f"**Очки:** {points} (всего активных: {new_total})\n"
            f"**Срок:** {expiry_text}\n**Причина:** {reason}"
        ),
        color=0xFFA500,
    )
    embed.set_footer(text=f"Выдал: {moderator}")

    if notify_channel:
        try:
            await notify_channel.send(embed=embed)
        except disnake.HTTPException:
            pass

    try:
        await member.send(
            f"⚠️ Вам выдано предупреждение на сервере **{guild.name}**.\n"
            f"Уровень: {level} | Срок: {expiry_text}\nПричина: {reason}"
        )
    except disnake.HTTPException:
        pass  # закрытые ЛС — не блокируем выдачу варна

    triggered = await apply_punishments(guild, member, config, old_total, new_total)
    if triggered and notify_channel:
        names = ", ".join(describe_punishment(p) for p in triggered)
        try:
            await notify_channel.send(f"🚨 Достигнут порог наказания ({new_total} очков): {names}")
        except disnake.HTTPException:
            pass

    await log_action(guild, config, embed)
    return warning_id


class ModerationCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.bot.loop.create_task(self._init_db())
        self.expire_warnings_loop.start()

    async def _init_db(self):
        await self.bot.wait_until_ready()
        await db.init()

    def cog_unload(self):
        self.expire_warnings_loop.cancel()

    # ==================== права и кулдауны ====================
    async def _check_permission(self, inter: disnake.ApplicationCommandInteraction,
                                 command: str, level: int | None = None) -> tuple[bool, str | None]:
        """Возвращает (можно_ли, сообщение_об_ошибке). Ничего сама не отправляет —
        только проверяет и, если доступ есть и кулдаун применим, сразу его засчитывает."""
        config = get_moderation_config(inter.guild.id)
        member = inter.author

        if _is_full_moderator(config, member):
            return True, None

        member_role_ids = {r.id for r in member.roles}
        grants = []
        for entry in config.get("role_permissions", []):
            if entry.get("role_id") not in member_role_ids:
                continue
            cmd_conf = entry.get("commands", {}).get(command)
            if cmd_conf is None:
                continue
            if level is not None and level not in cmd_conf.get("levels", []):
                continue
            grants.append(cmd_conf)

        if not grants:
            suffix = f" (уровень {level})" if level is not None else ""
            return False, f"<:Other_problem:1528536802720350370> У вас нет прав на эту команду{suffix}."

        cooldown = min(g.get("cooldown_seconds", 0) for g in grants)
        if cooldown:
            last = await db.get_command_cooldown(inter.guild.id, member.id, command)
            now = time.time()
            if last is not None and now - last < cooldown:
                wait = int(cooldown - (now - last))
                return False, (
                    f"<a:Loading:1528999376549314691> Эта команда доступна раз в {format_duration(cooldown)}. "
                    f"Подождите ещё {format_duration(wait)}."
                )
            await db.set_command_cooldown(inter.guild.id, member.id, command, now)

        return True, None

    # ==================== /re ====================
    @commands.slash_command(name="re", description="Обновить все панели (анкета/тикеты/предложения/войсы) в этом канале")
    async def re_slash(self, inter: disnake.ApplicationCommandInteraction):
        ok, err = await self._check_permission(inter, "re")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer()

        channel = inter.channel
        guild = inter.guild
        done = []

        if channel.id in ANKETA_CONFIGS:
            cog = self.bot.get_cog("AnketaCog")
            if cog:
                await cog.refresh_anketa_button(channel)
                done.append("анкета")

        if channel.id in TICKET_CONFIGS:
            cog = self.bot.get_cog("TicketsCog")
            if cog:
                await cog.refresh_ticket_button(channel)
                done.append("тикеты")

        if channel.id in SUGGESTION_CONFIGS:
            cog = self.bot.get_cog("SuggestionsCog")
            if cog:
                await cog.clean_old_suggestion_panels(channel)
                await cog.send_suggestion_panel(channel)
                done.append("предложения")

        voice_config = get_voice_config(guild.id)
        if voice_config.get("setting_channel") == channel.id:
            await send_or_update_panel(guild)
            done.append("настройки войсов")

        if not done:
            await inter.edit_original_response(content="<:Other_problem:1528536802720350370> В этом канале не найдено ни одной известной панели.")
        else:
            await inter.edit_original_response(content=f"✅ Обновлено: {', '.join(done)}.")

    # ==================== /clear ====================
    @commands.slash_command(name="clear", description="Удалить сообщения в этом канале")
    async def clear_slash(
        self, inter: disnake.ApplicationCommandInteraction,
        count: int = commands.Param(description="Сколько сообщений удалить", ge=1, le=500),
        member: disnake.Member = commands.Param(default=None, description="Только сообщения этого участника"),
    ):
        ok, err = await self._check_permission(inter, "clear")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer(ephemeral=True)

        matched = 0

        def check(msg: disnake.Message) -> bool:
            nonlocal matched
            if matched >= count:
                return False
            if member is not None and msg.author.id != member.id:
                return False
            matched += 1
            return True

        scan_limit = count if member is None else min(count * 20, 2000)
        deleted = await inter.channel.purge(limit=scan_limit, check=check)

        note = f" от {member.mention}" if member else ""
        await inter.edit_original_response(content=f"🧹 Удалено {len(deleted)} сообщений{note}.")

    # ==================== /warn ====================
    @commands.slash_command(name="warn", description="Выдать предупреждение участнику")
    async def warn_slash(
        self, inter: disnake.ApplicationCommandInteraction,
        member: disnake.Member = commands.Param(description="Кому выдать предупреждение"),
        level: int = commands.Param(choices=[1, 2, 3], description="Уровень предупреждения"),
        reason: str = commands.Param(description="Причина"),
        duration: str = commands.Param(default=None, description="Срок (7d, 12h, 30m...) — обязателен для уровня 1"),
    ):
        ok, err = await self._check_permission(inter, "warn", level=level)
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return

        if member.bot:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Ботам предупреждения не выдаются.", ephemeral=True)
            return

        config = get_moderation_config(inter.guild.id)
        duration_seconds = None

        if level in (1, 2) and duration:
            duration_seconds = parse_duration(duration)
            if duration_seconds is None:
                await inter.response.send_message(
                    "<:Other_problem:1528536802720350370> Не удалось распознать срок. Пример: `7d`, `12h`, `30m`.", ephemeral=True,
                )
                return

        if level == 1 and duration_seconds is None:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Для 1 уровня укажите срок (например 7d).", ephemeral=True)
            return

        if level == 2 and duration_seconds is None:
            default_dur = config.get("default_level2_duration_seconds")
            if default_dur:
                duration_seconds = default_dur

        if level == 3:
            duration_seconds = None  # уровень 3 всегда бессрочный

        await inter.response.defer()
        warning_id = await issue_warning(
            inter.guild, member, inter.author, level, reason, duration_seconds,
            notify_channel=inter.channel,
        )
        await inter.delete_original_response()

    # ==================== /warnings ====================
    @commands.slash_command(name="warnings", description="Список активных предупреждений участника")
    async def warnings_slash(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member):
        ok, err = await self._check_permission(inter, "warnings")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer()

        rows = await db.get_active_warnings(inter.guild.id, member.id)
        if not rows:
            await inter.edit_original_response(content=f"✅ У {member.mention} нет активных предупреждений.")
            return

        total = await db.get_total_points(inter.guild.id, member.id)
        embed = disnake.Embed(title=f"⚠️ Предупреждения — {member.display_name}", color=0xFFA500)
        for warning_id, level, points, reason, created_at, expires_at in rows:
            expiry_text = f"истекает <t:{int(expires_at)}:R>" if expires_at else "бессрочно"
            embed.add_field(
                name=f"#{warning_id} · уровень {level} · {points} очк.",
                value=f"{reason}\n_{expiry_text}, выдано <t:{int(created_at)}:D>_",
                inline=False,
            )
        embed.set_footer(text=f"Всего очков: {total}")
        await inter.edit_original_response(embed=embed)

    # ==================== /unwarn ====================
    @commands.slash_command(name="unwarn", description="Снять предупреждение по номеру")
    async def unwarn_slash(
        self, inter: disnake.ApplicationCommandInteraction,
        warning_id: int = commands.Param(name="id", description="Номер предупреждения (см. /warnings)"),
    ):
        ok, err = await self._check_permission(inter, "unwarn")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer()

        removed = await db.deactivate_warning(inter.guild.id, warning_id)
        if removed:
            await inter.edit_original_response(content=f"✅ Предупреждение #{warning_id} снято.")
        else:
            await inter.edit_original_response(content=f"<:Other_problem:1528536802720350370> Активное предупреждение #{warning_id} не найдено.")

    # ==================== /mute /unmute ====================
    @commands.slash_command(name="mute", description="Тайм-аут участнику")
    async def mute_slash(
        self, inter: disnake.ApplicationCommandInteraction,
        member: disnake.Member,
        duration: str = commands.Param(description="Например 10m, 2h, 1d"),
        reason: str = commands.Param(default="Не указана"),
    ):
        ok, err = await self._check_permission(inter, "mute")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        seconds = parse_duration(duration)
        if seconds is None:
            await inter.response.send_message("<:Other_problem:1528536802720350370> Укажите срок в формате `10m`, `2h`, `1d`.", ephemeral=True)
            return
        await inter.response.defer()

        until = disnake.utils.utcnow() + datetime.timedelta(seconds=seconds)
        try:
            await member.timeout(until=until, reason=f"{reason} (от {inter.author})")
        except disnake.HTTPException as e:
            await inter.edit_original_response(content=f"<:Other_problem:1528536802720350370> Не удалось замьютить: {e}")
            return
        await inter.edit_original_response(
            content=f"🔇 {member.mention} в тайм-ауте на {format_duration(seconds)}. Причина: {reason}"
        )

    @commands.slash_command(name="unmute", description="Снять тайм-аут с участника")
    async def unmute_slash(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member):
        ok, err = await self._check_permission(inter, "unmute")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer()
        try:
            await member.timeout(until=None)
        except disnake.HTTPException as e:
            await inter.edit_original_response(content=f"<:Other_problem:1528536802720350370> Не удалось снять тайм-аут: {e}")
            return
        await inter.edit_original_response(content=f"🔊 Тайм-аут с {member.mention} снят.")

    # ==================== /kick /ban ====================
    @commands.slash_command(name="kick", description="Выгнать участника с сервера")
    async def kick_slash(
        self, inter: disnake.ApplicationCommandInteraction,
        member: disnake.Member, reason: str = commands.Param(default="Не указана"),
    ):
        ok, err = await self._check_permission(inter, "kick")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer()
        try:
            await member.kick(reason=f"{reason} (от {inter.author})")
        except disnake.HTTPException as e:
            await inter.edit_original_response(content=f"<:Other_problem:1528536802720350370> Не удалось выгнать: {e}")
            return
        await inter.edit_original_response(content=f"👢 {member.mention} выгнан. Причина: {reason}")

    @commands.slash_command(name="ban", description="Забанить участника")
    async def ban_slash(
        self, inter: disnake.ApplicationCommandInteraction,
        member: disnake.Member, reason: str = commands.Param(default="Не указана"),
    ):
        ok, err = await self._check_permission(inter, "ban")
        if not ok:
            await inter.response.send_message(err, ephemeral=True)
            return
        await inter.response.defer()
        try:
            await member.ban(reason=f"{reason} (от {inter.author})")
        except disnake.HTTPException as e:
            await inter.edit_original_response(content=f"<:Other_problem:1528536802720350370> Не удалось забанить: {e}")
            return
        await inter.edit_original_response(content=f"🔨 {member.mention} забанен. Причина: {reason}")

    # ==================== /info ====================
    @commands.slash_command(name="info", description="Информация об участнике или сервере")
    async def info_group(self, inter: disnake.ApplicationCommandInteraction):
        pass  # группа — вызываются только подкоманды ниже

    @info_group.sub_command(name="user", description="Информация об участнике (по умолчанию — о себе)")
    async def info_user(
        self, inter: disnake.ApplicationCommandInteraction,
        member: disnake.Member = commands.Param(default=None, description="Оставьте пустым, чтобы посмотреть свой профиль"),
    ):
        await inter.response.defer()
        target = member or inter.author
        config = get_moderation_config(inter.guild.id)

        embed = disnake.Embed(title=f"👤 {target.display_name}", color=target.color or 0x5865F2)
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.add_field(name="На сервере с", value=disnake.utils.format_dt(target.joined_at, "D") if target.joined_at else "—", inline=True)
        embed.add_field(name="Аккаунт создан", value=disnake.utils.format_dt(target.created_at, "D"), inline=True)
        roles = [r.mention for r in reversed(target.roles) if r.name != "@everyone"][:10]
        embed.add_field(name="Роли", value=", ".join(roles) if roles else "—", inline=False)

        # Предупреждения — только себе или если смотрящий сам из модерации
        # (чтобы обычные участники не листали чужие варны через /info).
        if target.id == inter.author.id or _is_staff(config, inter.author):
            total = await db.get_total_points(inter.guild.id, target.id)
            active = await db.get_active_warnings(inter.guild.id, target.id)
            embed.add_field(name="Активные предупреждения", value=f"{len(active)} шт. ({total} очков)", inline=False)
            flags = await get_active_flags(inter.guild.id, target.id)
            if flags:
                embed.add_field(name="Активные ограничения", value=", ".join(f"`{f}`" for f in sorted(flags)), inline=False)

        await inter.edit_original_response(embed=embed)

    @info_group.sub_command(name="server", description="Информация о сервере")
    async def info_server(self, inter: disnake.ApplicationCommandInteraction):
        await inter.response.defer()
        guild = inter.guild
        embed = disnake.Embed(title=f"🖥️ {guild.name}", color=0x5865F2)
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Владелец", value=guild.owner.mention if guild.owner else "—", inline=True)
        embed.add_field(name="Участников", value=str(guild.member_count), inline=True)
        embed.add_field(name="Создан", value=disnake.utils.format_dt(guild.created_at, "D"), inline=True)
        embed.add_field(name="Текстовых каналов", value=str(len(guild.text_channels)), inline=True)
        embed.add_field(name="Голосовых каналов", value=str(len(guild.voice_channels)), inline=True)
        embed.add_field(name="Ролей", value=str(len(guild.roles)), inline=True)
        embed.add_field(
            name="Буст-статус",
            value=f"Уровень {guild.premium_tier} ({guild.premium_subscription_count} бустов)",
            inline=True,
        )
        await inter.edit_original_response(embed=embed)

    # ==================== вспомогательное ====================
    # apply_punishments / describe_punishment / log_action / issue_warning
    # вынесены на уровень модуля выше — их же использует cogs/automod.py.



    # ==================== фоновая задача: снятие истёкших предупреждений ====================
    @tasks.loop(minutes=5)
    async def expire_warnings_loop(self):
        try:
            expired = await db.get_expired_warnings(time.time())
            for warning_id, guild_id, user_id in expired:
                await db.expire_warning(warning_id)
                log.info("Предупреждение #%s (guild=%s, user=%s) истекло и снято.", warning_id, guild_id, user_id)
        except Exception as e:
            log.error("Ошибка в фоновой задаче снятия предупреждений: %s", e)

    @expire_warnings_loop.before_loop
    async def before_expire_loop(self):
        await self.bot.wait_until_ready()
        await db.init()  # идемпотентно — но без этого цикл мог стартовать
                          # раньше, чем _init_db() успевал завершиться, и
                          # первый же запрос падал с 'NoneType' object has
                          # no attribute 'execute' (соединение ещё не готово)


def setup(bot: commands.Bot):
    bot.add_cog(ModerationCog(bot))
