"""
Автомодерация: запрещённые слова, антиспам, фильтр инвайт-ссылок.

Важно: срабатывание выдаёт НАСТОЯЩЕЕ предупреждение через ту же функцию
issue_warning(), что и команда /warn (cogs/moderation.py) — те же очки,
сроки, автонаказания по порогам и лог. Никакой отдельной логики наказаний
здесь нет, чтобы варны от бота и от живых модераторов вели себя одинаково.

Всё выключено по умолчанию (enabled: False) — включайте и настраивайте
через AUTOMOD_CONFIGS в dealer_bot.py.
"""

import logging
import re
import time

import disnake
from disnake.ext import commands

from dealer_bot import get_automod_config
from cogs.moderation import issue_warning
from banned_words import BANNED_WORDS, SAFE_WORDS
from restrictions import has_flag, get_soft_slowmode_seconds
from profanity_filter import contains_banned_word

log = logging.getLogger("automod_cog")

INVITE_RE = re.compile(r"(discord\.gg/|discord(?:app)?\.com/invite/)\S+", re.IGNORECASE)
LINK_RE = re.compile(r"https?://\S+", re.IGNORECASE)
MENTION_RE = re.compile(r"<@&\d+>|@everyone|@here")

# guild_id -> {user_id: [временные метки сообщений]} — скользящее окно для
# антиспама. Только в памяти: это детектор реального времени, не история,
# терять его при рестарте бота не страшно.
_recent_messages: dict[int, dict[int, list[float]]] = {}

# guild_id -> {user_id: время последнего сообщения} — для "мягкого" slowmode
# по очкам предупреждений (персональный, в отличие от настоящего Discord
# slowmode, который общий на канал и не умеет быть точечным per-user).
_last_message_at: dict[int, dict[int, float]] = {}


def _is_spam(guild_id: int, user_id: int, threshold: int, interval: float) -> bool:
    now = time.time()
    history = _recent_messages.setdefault(guild_id, {}).setdefault(user_id, [])
    history[:] = [t for t in history if now - t < interval]
    history.append(now)
    return len(history) >= threshold


def _too_fast(guild_id: int, user_id: int, min_interval: float) -> bool:
    now = time.time()
    last = _last_message_at.setdefault(guild_id, {}).get(user_id)
    _last_message_at[guild_id][user_id] = now
    return last is not None and now - last < min_interval


class AutomodCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot or not message.guild:
            return
        config = get_automod_config(message.guild.id)
        if not config.get("enabled"):
            return
        if message.channel.id in config.get("ignore_channels", []):
            return
        member_role_ids = {r.id for r in message.author.roles}
        if member_role_ids & set(config.get("ignore_roles", [])):
            return
        if message.author.guild_permissions.administrator:
            return

        guild_id = message.guild.id
        user_id = message.author.id

        # ---- read_only: участнику вообще нельзя писать в обычных чатах ----
        # (кроме каналов из read_only_exempt_channels — например поддержка,
        # где человек должен иметь возможность оспорить наказание)
        if message.channel.id not in config.get("read_only_exempt_channels", []):
            if await has_flag(guild_id, user_id, "read_only"):
                try:
                    await message.delete()
                except disnake.HTTPException:
                    pass
                return

        # ---- запрещённые слова ----
        # Основной список — из banned_words.py, плюс необязательные
        # дополнительные слова конкретно для этого сервера из конфига.
        banned_words = BANNED_WORDS + config.get("extra_banned_words", [])
        safe_words = SAFE_WORDS + config.get("extra_safe_words", [])
        hit = contains_banned_word(message.content, banned_words, safe_words)
        if hit:
            await self._handle_violation(
                message, config,
                delete=config.get("banned_word_delete", True),
                warn_level=config.get("banned_word_warn_level", 1),
                warn_duration=config.get("banned_word_warn_duration_seconds", 3600),
                reason=config.get("banned_word_warn_reason", "Автомодерация: запрещённое слово"),
            )
            return

        # ---- инвайты на сторонние сервера ----
        if config.get("invite_filter_enabled") and INVITE_RE.search(message.content):
            await self._handle_violation(
                message, config,
                delete=config.get("invite_delete", True),
                warn_level=config.get("invite_warn_level", 1),
                warn_duration=config.get("invite_warn_duration_seconds", 3600),
                reason=config.get("invite_warn_reason", "Автомодерация: приглашение на сторонний сервер"),
            )
            return

        # ---- ссылки (по очкам предупреждений — flag "no_links") ----
        if LINK_RE.search(message.content) and await has_flag(guild_id, user_id, "no_links"):
            try:
                await message.delete()
            except disnake.HTTPException:
                pass
            return

        # ---- картинки/файлы (flag "no_images") ----
        if message.attachments and await has_flag(guild_id, user_id, "no_images"):
            try:
                await message.delete()
            except disnake.HTTPException:
                pass
            return

        # ---- упоминания ролей/@everyone/@here (flag "no_mentions") ----
        if (message.role_mentions or message.mention_everyone) and await has_flag(guild_id, user_id, "no_mentions"):
            try:
                await message.delete()
            except disnake.HTTPException:
                pass
            return

        # ---- спам (жёсткий детектор: N сообщений за M секунд) ----
        if config.get("spam_enabled") and _is_spam(
            guild_id, user_id,
            config.get("spam_message_threshold", 5), config.get("spam_interval_seconds", 5),
        ):
            await self._handle_violation(
                message, config,
                delete=config.get("spam_delete", True),
                warn_level=config.get("spam_warn_level", 1),
                warn_duration=config.get("spam_warn_duration_seconds", 1800),
                reason=config.get("spam_warn_reason", "Автомодерация: спам сообщениями"),
            )
            return

        # ---- "мягкий" slowmode по очкам предупреждений (персональный) ----
        # Настоящий Discord slowmode (channel.edit(slowmode_delay=...)) общий
        # на канал и не может быть точечным для одного участника — поэтому
        # эмулируем персональный интервал между сообщениями на стороне бота.
        min_interval = await get_soft_slowmode_seconds(guild_id, user_id)
        if min_interval and _too_fast(guild_id, user_id, min_interval):
            try:
                await message.delete()
            except disnake.HTTPException:
                pass
            return

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: disnake.RawReactionActionEvent):
        # Реакции идут отдельным событием от сообщений — ставить их на ЧУЖИЕ
        # сообщения message.delete() не решает, поэтому здесь просто убираем
        # саму реакцию нарушителя.
        if payload.member is None or payload.member.bot or payload.guild_id is None:
            return
        config = get_automod_config(payload.guild_id)
        if not config.get("enabled"):
            return
        if payload.member.guild_permissions.administrator:
            return
        if not await has_flag(payload.guild_id, payload.user_id, "no_reactions"):
            return
        channel = self.bot.get_channel(payload.channel_id)
        if not channel:
            return
        try:
            message = await channel.fetch_message(payload.message_id)
            await message.remove_reaction(payload.emoji, payload.member)
        except disnake.HTTPException:
            pass

    async def _handle_violation(self, message: disnake.Message, config: dict,
                                 delete: bool, warn_level: int, warn_duration: int, reason: str):
        if delete:
            try:
                await message.delete()
            except disnake.HTTPException:
                pass

        duration = None
        if warn_level in (1, 2):
            duration = warn_duration or 3600  # не даём случайно сделать "вечный" 1 уровень

        try:
            await issue_warning(
                message.guild, message.author, self.bot.user, warn_level, reason, duration,
                notify_channel=message.channel,
            )
        except disnake.HTTPException as e:
            log.warning("Не удалось выдать автопредупреждение %s: %s", message.author.id, e)


def setup(bot: commands.Bot):
    bot.add_cog(AutomodCog(bot))
