"""
Приветствие/прощание участников + автовыдача роли при входе + благодарность за буст.
"""
import logging
import datetime

import disnake
from disnake.ext import commands

from dealer_bot import get_greetings_config

log = logging.getLogger("greetings_cog")


def _format(template: str, member: disnake.Member) -> str:
    return template.format(
        mention=member.mention,
        user=member.display_name,
        server=member.guild.name,
        member_count=member.guild.member_count,
    )


class GreetingsCog(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        if member.bot:
            return
        config = get_greetings_config(member.guild.id)

        # автовыдача роли
        role_id = config.get("auto_role_id")
        if role_id:
            role = member.guild.get_role(role_id)
            if role:
                try:
                    await member.add_roles(role, reason="Автовыдача роли при входе")
                except disnake.HTTPException as e:
                    log.warning("Не удалось выдать автороль %s участнику %s: %s", role_id, member.id, e)

        if not config.get("welcome_enabled"):
            return
        channel = member.guild.get_channel(config.get("welcome_channel_id"))
        if not channel:
            return

        embed = disnake.Embed(
            title=config.get("welcome_title", "👋 Добро пожаловать!"),
            description=_format(config.get("welcome_description", ""), member),
            color=config.get("welcome_color", 0x57F287),
        )
        if config.get("welcome_show_avatar", True):
            embed.set_thumbnail(url=member.display_avatar.url)
        if config.get("welcome_image"):
            embed.set_image(url=config["welcome_image"])
        embed.timestamp = disnake.utils.utcnow()
        try:
            await channel.send(embed=embed)
        except disnake.HTTPException as e:
            log.warning("Не удалось отправить приветствие в канал %s: %s", channel.id, e)

    @commands.Cog.listener()
    async def on_member_remove(self, member: disnake.Member):
        if member.bot:
            return
        config = get_greetings_config(member.guild.id)
        if not config.get("farewell_enabled"):
            return

        channel_id = config.get("farewell_channel_id") or config.get("welcome_channel_id")
        channel = member.guild.get_channel(channel_id)
        if not channel:
            return

        embed = disnake.Embed(
            title=config.get("farewell_title", "👋 До встречи"),
            description=_format(config.get("farewell_description", ""), member),
            color=config.get("farewell_color", 0xED4245),
        )

        try:
            await channel.send(embed=embed)
        except disnake.HTTPException as e:
            log.warning("Не удалось отправить прощание в канал %s: %s", channel.id, e)

    @commands.Cog.listener()
    async def on_member_update(self, before: disnake.Member, after: disnake.Member):
        # Буст сервера определяется по появлению premium_since (раньше не
        # был бустером, стал им сейчас).
        if before.premium_since is None and after.premium_since is not None:
            config = get_greetings_config(after.guild.id)
            if not config.get("boost_enabled"):
                return
            channel_id = config.get("boost_channel_id") or config.get("welcome_channel_id")
            channel = after.guild.get_channel(channel_id)
            if not channel:
                return
            embed = disnake.Embed(
                description=_format(config.get("boost_message", ""), after),
                color=config.get("boost_color", 0xF47FFF),
            )
            try:
                await channel.send(embed=embed)
            except disnake.HTTPException as e:
                log.warning("Не удалось отправить благодарность за буст в канал %s: %s", channel.id, e)


def setup(bot: commands.Bot):
    bot.add_cog(GreetingsCog(bot))
